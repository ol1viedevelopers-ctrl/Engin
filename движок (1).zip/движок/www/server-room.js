// Универсальная комната. Правила игры задаются в server-rules.js
const { Room } = require("colyseus");
const { Player, GameState } = require("./server-schema.js");

let rules = {};
try {
  rules = require("./server-rules.js");
} catch (e) {
  console.log("[Room] server-rules.js не найден, используется пустая логика");
}

const MAX_SPEED = 400;
const SPEED_ALLOWANCE = 50;

class GameRoom extends Room {
  onCreate(options) {
    this.maxClients = options.maxPlayers || 8;
    this.setState(new GameState());
    this.tickInterval = null;
    this.lastMoves = new Map();
    this._spawns = null;

    this.onMessage("move", (c, d) => this.handleMove(c, d));
    this.onMessage("custom", (c, d) => this.handleCustom(c, d));
    this.onMessage("broadcast", (c, d) => this.handleBroadcast(c, d));

    this.tickInterval = setInterval(() => {
      if (this.state.phase === "playing" && rules.onTick) {
        try { rules.onTick(this, 0.1); }
        catch (e) { console.error("[Rules] onTick:", e); }
      }
    }, 100);
  }

  handleMove(client, data) {
    const p = this.state.players.get(client.sessionId);
    if (!p || !p.alive) return;
    if (this.state.phase !== "playing") return;
    const x = Number(data && data.x), y = Number(data && data.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return;

    const sid = client.sessionId;
    const now = Date.now();
    const last = this.lastMoves.get(sid);

    if (!last) {
      p.x = Math.max(0, Math.min(100000, x));
      p.y = Math.max(0, Math.min(100000, y));
      this.lastMoves.set(sid, { x: p.x, y: p.y, t: now });
      return;
    }

    const dt = Math.max(0, now - last.t) / 1000;
    const dx = x - last.x;
    const dy = y - last.y;
    const dist = Math.hypot(dx, dy);

    if (dt < 0.02) return;

    const maxDist = MAX_SPEED * dt + SPEED_ALLOWANCE;

    if (dist > maxDist) {
      const k = maxDist / dist;
      p.x = last.x + dx * k;
      p.y = last.y + dy * k;
      console.warn(`[AntiCheat] ${p.name}: ${dist.toFixed(0)}px / ${(dt*1000).toFixed(0)}ms > ${maxDist.toFixed(0)}`);
    } else {
      p.x = Math.max(0, Math.min(100000, x));
      p.y = Math.max(0, Math.min(100000, y));
    }

    this.lastMoves.set(sid, { x: p.x, y: p.y, t: now });
  }

  handleStart(client, data) {
    if (client.sessionId !== this.state.hostId) return;
    if (this.state.phase !== "lobby") return;
    if (this.state.players.size < 2) {
      client.send("error", { message: "Нужно минимум 2 игрока" });
      return;
    }

    // Спавны из сцены хоста
    if (data && Array.isArray(data.spawns) && data.spawns.length > 0) {
      this._spawns = data.spawns
        .filter(s => s && Number.isFinite(s.x) && Number.isFinite(s.y))
        .map(s => ({ x: Number(s.x), y: Number(s.y) }))
        .slice(0, 32);
    }

    let ok = true;
    if (rules.onStart) {
      try { ok = rules.onStart(this) !== false; }
      catch (e) { console.error("[Rules] onStart:", e); ok = false; }
    }
    if (!ok) return;
    this.lastMoves.clear();
    this.state.phase = "playing";
    this.broadcast("started", {});
  }

  handleCustom(client, data) {
    if (!data || !data.type) return;
    const p = this.state.players.get(client.sessionId);
    if (!p) return;

    if (data.type === "_hide") {
      p.hidden = !!(data.data && data.data.v);
      return;
    }

    // Спец: startGame приходит как custom
    if (data.type === "startGame") {
      this.handleStart(client, data.data);
      return;
    }

    if (rules.onMessage) {
      try { rules.onMessage(this, client, data.type, data.data); }
      catch (e) { console.error("[Rules] onMessage:", e); }
    }
    this.broadcast("net", {
      type: data.type,
      data: data.data,
      from: client.sessionId
    });
  }

  handleBroadcast(client, data) {
    if (!data || !data.type) return;
    this.broadcast("net", {
      type: data.type,
      data: data.data,
      from: client.sessionId
    }, { except: client });
  }

  onJoin(client, options) {
    const player = new Player();
    player.name = String((options && options.name) || "Игрок").slice(0, 16);
    player.color = String((options && options.color) || "#00F59B");
    if (!this.state.hostId) this.state.hostId = client.sessionId;
    this.state.players.set(client.sessionId, player);
    this.lastMoves.delete(client.sessionId);
    client.send("welcome", { id: client.sessionId });
    if (rules.onJoin) {
      try { rules.onJoin(this, player, options, client.sessionId); }
      catch (e) { console.error("[Rules] onJoin:", e); }
    }
  }

  onLeave(client) {
    const player = this.state.players.get(client.sessionId);
    if (player && rules.onLeave) {
      try { rules.onLeave(this, player); }
      catch (e) { console.error("[Rules] onLeave:", e); }
    }
    this.state.players.delete(client.sessionId);
    this.lastMoves.delete(client.sessionId);
    if (this.state.hostId === client.sessionId) {
      const it = this.state.players.keys().next();
      this.state.hostId = it.done ? "" : it.value;
    }
    if (this.state.phase === "playing" && rules.onTick) {
      try { rules.onTick(this, 0); }
      catch (e) {}
    }
  }

  onDispose() {
    if (this.tickInterval) clearInterval(this.tickInterval);
  }
}

module.exports = { GameRoom };