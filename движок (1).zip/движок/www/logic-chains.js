// ============================================================================
// LOGIC-CHAINS.JS — No-Code логика в виде цепочек действий
// ----------------------------------------------------------------------------
// Структура правила:
// {
//   id, enabled,
//   when: { sourceId: "obj_x" | "any", event: "onTap" | "onStart" | ... },
//   condition: { varName: "score", op: ">", value: 10 } | null,
//   then: [ { action, params }, ... ]
// }
// ============================================================================

(function () {
  "use strict";

  const OPS = {
    ">":  (a, b) => a > b,
    "<":  (a, b) => a < b,
    "==": (a, b) => a == b,
    "!=": (a, b) => a != b,
    ">=": (a, b) => a >= b,
    "<=": (a, b) => a <= b
  };

  function dispatch({ event, trigger, context, state, camera, getSceneObjects }) {
    const rules = state.logicRules || [];
    for (const rule of rules) {
      if (rule.enabled === false) continue;
      if (rule.when?.event !== event) continue;
      if (rule.when?.sourceId !== "any" && trigger && rule.when.sourceId !== trigger.id) continue;
      if (rule.condition && !_checkCondition(rule.condition, state)) continue;

      const target = trigger
        || getSceneObjects().find(o => o.id === rule.when.sourceId)
        || getSceneObjects()[0];

      for (const action of (rule.then || [])) {
        _runAction(action, target, state, camera, getSceneObjects, context);
      }
    }
  }

  function _checkCondition(cond, state) {
    const v = state.variables.find(x => x.name === cond.varName);
    if (!v) return false;
    const op = OPS[cond.op];
    if (!op) return true;
    return op(v.value, cond.value);
  }

  function _runAction(action, target, state, camera, getSceneObjects, context) {
    const p = action.params || {};
    const objects = getSceneObjects();

    switch (action.action) {
      case "setVar": {
        const v = state.variables.find(x => x.name === p.name);
        if (!v) break;
        const num = Number(p.value) || 0;
        if (p.mode === "add") v.value = Number(v.value) + num;
        else if (p.mode === "sub") v.value = Number(v.value) - num;
        else v.value = v.type === "number" ? num : p.value;
        break;
      }
      case "setLight": {
        const light = p.targetId
          ? objects.find(o => o.id === p.targetId)
          : objects.find(o => o.type === "light");
        if (!light) break;
        if (p.radius    != null) light.radius    = Number(p.radius);
        if (p.intensity != null) light.intensity = Number(p.intensity);
        if (p.softness  != null) light.softness  = Number(p.softness);
        if (p.rgba)              light.rgba      = p.rgba;
        break;
      }
      case "setAnim": if (target) target.anim = p.anim || "idle"; break;
      case "jump":    if (target) { target.vy = -420; target.anim = "jump"; } break;
      case "move":    if (target) { target.x += Number(p.dx) || 0; target.y += Number(p.dy) || 0; } break;
      case "destroy": {
        const list = target ? [target] : objects;
        for (const t of list) {
          const i = objects.indexOf(t);
          if (i !== -1) objects.splice(i, 1);
        }
        break;
      }
      case "switchScene":
        if (state.scenes.length > 1)
          state.activeSceneIndex = (state.activeSceneIndex + 1) % state.scenes.length;
        break;
      case "spawn":
        if (window.createSceneObject) {
          const o = window.createSceneObject(p.presetType || "rect");
          if (p.x != null) o.x = Number(p.x);
          if (p.y != null) o.y = Number(p.y);
        }
        break;
      case "playSound":
        try {
          const a = new Audio(p.url);
          a.volume = Math.max(0, Math.min(1, Number(p.volume ?? 1)));
          a.play().catch(() => {});
        } catch (_) {}
        break;
    }
  }

  // ==================== UI-КОНСТРУКТОР ====================
  function renderBuilder(state, rootEl, refreshList) {
    if (!rootEl) return;

    const scene = state.scenes[state.activeSceneIndex];
    const objectOptions = [
      '<option value="any">Любой объект</option>',
      ...scene.objects.map(o => `<option value="${o.id}">${o.name}</option>`)
    ].join("");

    const varOptions = state.variables.map(v =>
      `<option value="${v.name}">${v.name}</option>`).join("");

    rootEl.innerHTML = `
      <div class="chain-block">
        <div class="chain-row">
          <span class="chain-tag tag-when">КОГДА</span>
          <select id="rule-when-obj" class="sel">${objectOptions}</select>
          <select id="rule-when-event" class="sel">
            <option value="onTap">При таче по объекту</option>
            <option value="onStart">При старте сцены (PLAY)</option>
            <option value="onCollide">При столкновении</option>
            <option value="onTick">Каждую секунду</option>
          </select>
        </div>

        <div class="chain-row">
          <span class="chain-tag tag-if">ТОЛЬКО ЕСЛИ</span>
          <select id="rule-cond-var" class="sel">
            <option value="">— без условия —</option>
            ${varOptions}
          </select>
          <select id="rule-cond-op" class="sel">
            <option value=">">&gt;</option>
            <option value="<">&lt;</option>
            <option value="==">==</option>
            <option value="!=">!=</option>
            <option value=">=">&gt;=</option>
            <option value="<=">&lt;=</option>
          </select>
          <input id="rule-cond-val" class="inp" type="text" placeholder="Значение" />
        </div>

        <div class="chain-row chain-then-header">
          <span class="chain-tag tag-then">ТОГДА</span>
          <button id="rule-add-action" class="action-btn primary" type="button">+ действие</button>
        </div>
        <div id="rule-actions-list" class="chain-actions-list"></div>

        <button id="rule-save" class="action-btn primary" type="button" style="margin-top:10px;">Сохранить правило</button>
      </div>
    `;

    const actionsRoot = rootEl.querySelector("#rule-actions-list");

    function addActionRow() {
      const row = document.createElement("div");
      row.className = "chain-action-row";
      row.innerHTML = `
        <select class="sel action-type">
          <option value="setVar">Изменить переменную</option>
          <option value="setLight">Изменить свет</option>
          <option value="setAnim">Сменить анимацию</option>
          <option value="jump">Прыжок</option>
          <option value="move">Сдвинуть</option>
          <option value="destroy">Уничтожить</option>
          <option value="switchScene">Следующая сцена</option>
          <option value="spawn">Создать объект</option>
        </select>
        <input class="inp action-p1" placeholder="p1" />
        <input class="inp action-p2" placeholder="p2" />
        <button class="action-btn danger action-remove" type="button">✕</button>
      `;
      row.querySelector(".action-remove").onclick = () => row.remove();
      actionsRoot.appendChild(row);
    }

    rootEl.querySelector("#rule-add-action").onclick = addActionRow;
    addActionRow();

    rootEl.querySelector("#rule-save").onclick = () => {
      const whenObj = rootEl.querySelector("#rule-when-obj").value;
      const whenEv  = rootEl.querySelector("#rule-when-event").value;
      const condVar = rootEl.querySelector("#rule-cond-var").value;
      const condOp  = rootEl.querySelector("#rule-cond-op").value;
      const condVal = rootEl.querySelector("#rule-cond-val").value;

      const then = [];
      actionsRoot.querySelectorAll(".chain-action-row").forEach(r => {
        const action = r.querySelector(".action-type").value;
        const p1 = r.querySelector(".action-p1").value.trim();
        const p2 = r.querySelector(".action-p2").value.trim();
        then.push(_buildAction(action, p1, p2));
      });

      state.logicRules.push({
        id: "rule_" + Date.now(),
        enabled: true,
        when: { sourceId: whenObj, event: whenEv },
        condition: condVar
          ? { varName: condVar, op: condOp, value: isNaN(+condVal) ? condVal : +condVal }
          : null,
        then
      });

      refreshList?.();
    };
  }

  function _buildAction(type, p1, p2) {
    switch (type) {
      case "setVar":   return { action: "setVar",   params: { name: p1, mode: "add", value: +p2 || 1 } };
      case "setLight": return { action: "setLight", params: { radius: +p1 || 300, intensity: +p2 || 0.9 } };
      case "setAnim":  return { action: "setAnim",  params: { anim: p1 || "idle" } };
      case "jump":     return { action: "jump",     params: {} };
      case "move":     return { action: "move",     params: { dx: +p1 || 0, dy: +p2 || 0 } };
      case "destroy":  return { action: "destroy",  params: {} };
      case "switchScene": return { action: "switchScene", params: {} };
      case "spawn":    return { action: "spawn",    params: { presetType: p1 || "rect" } };
      default:         return { action: type,       params: { p1, p2 } };
    }
  }

  function migrateOldRules(rules) {
    if (!Array.isArray(rules)) return [];
    return rules.map(r => {
      if (Array.isArray(r.then)) return r;
      return {
        id: r.id || ("rule_" + Math.random().toString(36).slice(2, 8)),
        enabled: true,
        when: { sourceId: r.sourceId || "any", event: r.event || "onTap" },
        condition: null,
        then: [{ action: r.action || "jump", params: { value: r.param, anim: r.param } }]
      };
    });
  }

  window.LogicChains = { dispatch, renderBuilder, migrateOldRules };
})();