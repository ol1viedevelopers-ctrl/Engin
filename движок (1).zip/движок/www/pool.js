// pool.js — пул объектов
class ObjectPool {
  constructor(factory, resetFn, initialSize = 32) {
    this.factory = factory;
    this.resetFn = resetFn;
    this.free = [];
    this.active = new Set();
    for (let i = 0; i < initialSize; i++) this.free.push(factory());
  }
  acquire() {
    const obj = this.free.pop() || this.factory();
    this.active.add(obj);
    return obj;
  }
  release(obj) {
    if (!this.active.has(obj)) return;
    this.active.delete(obj);
    this.resetFn(obj);
    this.free.push(obj);
  }
  releaseAll() {
    for (const obj of this.active) { this.resetFn(obj); this.free.push(obj); }
    this.active.clear();
  }
  forEachActive(fn) { for (const obj of this.active) fn(obj); }
}
window.ObjectPool = ObjectPool;