const http = require("http");
const express = require("express");
const { Server } = require("colyseus");
const { monitor } = require("@colyseus/monitor");
const { GameRoom } = require("./server-room.js");

const port = Number(process.env.PORT) || 2567;

const app = express();
app.use(express.json());
app.use("/colyseus", monitor());

const server = http.createServer(app);
const gameServer = new Server({ server });

gameServer.define("game_room", GameRoom);
gameServer.listen(port);

console.log(`🎮 TapEng1ne server ready on ws://localhost:${port}`);
console.log(`📊 Monitor: http://localhost:${port}/colyseus`);