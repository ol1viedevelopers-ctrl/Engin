// net.js — универсальная обёртка Colyseus (редактор + runtime)
(function () {
  "use strict";

  let client = null;
  let room = null;
  let myId = null;
  const listeners = new Map();
  let isConnected = false;

  function getServerUrl() {
    return (
      window.NET_SERVER_URL ||
      (window.EngineState && window.EngineState.serverUrl) ||
      "wss://localhost:2567"
    );
  }

  async function connect(serverUrl) {
    if (!window.Colyseus || !window.Colyseus.Client) {
      throw new Error("Colyseus не загружен");
    }
    const url = serverUrl || getServerUrl();
    client = new window.Colyseus.Client(url);
    isConnected = true;
    emit("connected", { url: url });
    return client;
  }

  async function host(opts) {
    opts = opts || {};
    if (!client) await connect();
    room = await client.create("game_room", {
      maxPlayers: opts.maxPlayers || 8,
      name: opts.name || "Игрок",
      color: opts.color || "#00F59B"
    });
    myId = room.sessionId;
    bindRoomEvents();
    emit("joined", { roomId: room.id, myId: myId });
    return room.id;
  }

  async function joinRoom(roomId, opts) {
    opts = opts || {};
    if (!client) await connect();
    room = await client.joinById(roomId, {
      name: opts.name || "Игрок",
      color: opts.color || "#00F59B"
    });
    myId = room.sessionId;
    bindRoomEvents();
    emit("joined", { roomId: room.id, myId: myId });
    return room.id;
  }

  function bindRoomEvents() {
    room.onStateChange(function (state) { emit("stateChange", state); });
    room.onMessage("welcome", function (d) { emit("welcome", d); });
    room.onMessage("started", function (d) { emit("started", d); });
    room.onMessage("ended", function (d) { emit("ended", d); });
    room.onMessage("meetingEnded", function (d) { emit("meetingEnded", d); });
    room.onMessage("playerKilled", function (d) { emit("playerKilled", d); });
    room.onMessage("error", function (d) { emit("error", d); });
    room.onMessage("event", function (d) { emit(d.type, d.payload, d.from); });

    room.onLeave(function (code) {
      room = null;
      myId = null;
      isConnected = false;
      emit("disconnect", { code: code });
    });

    room.onError(function (code, message) {
      emit("error", { code: code, message: message });
    });
  }

  function send(type, payload) {
    if (!room) return false;
    room.send("event", { type: type, payload: payload });
    return true;
  }

  function on(type, handler) {
    if (!listeners.has(type)) listeners.set(type, []);
    listeners.get(type).push(handler);
    return function () {
      const arr = listeners.get(type);
      if (!arr) return;
      const i = arr.indexOf(handler);
      if (i !== -1) arr.splice(i, 1);
    };
  }

  function emit(type) {
    const args = Array.prototype.slice.call(arguments, 1);
    const list = listeners.get(type) || [];
    for (const fn of list) {
      try { fn.apply(null, args); }
      catch (e) { console.warn("[TapNet]", type, e); }
    }
  }

  function players() {
    if (!room || !room.state || !room.state.players) return [];
    const map = room.state.players;
    const arr = [];
    if (map.forEach) {
      map.forEach(function (v, k) { arr.push(Object.assign({ id: k }, v)); });
    } else {
      for (const id of Object.keys(map)) arr.push(Object.assign({ id: id }, map[id]));
    }
    return arr;
  }

  function leave() {
    if (room) { room.leave(); room = null; }
    myId = null;
    isConnected = false;
  }

  window.TapNet = {
    connect: connect,
    host: host,
    joinRoom: joinRoom,
    send: send,
    on: on,
    players: players,
    leave: leave,
    isConnected: function () { return isConnected && !!room; },
    getRoom: function () { return room; },
    getMyId: function () { return myId; },
    getServerUrl: getServerUrl
  };
})();