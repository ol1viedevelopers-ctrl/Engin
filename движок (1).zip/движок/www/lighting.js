// LIGHTING.JS — WebGL2-свет с окклюдерами
(function () {
  "use strict";

  const VERT_SRC = `#version 300 es
  precision highp float;
  in vec2 a_world;
  uniform vec2 u_resolution;
  uniform vec2 u_camera;
  uniform float u_zoom;
  out vec2 v_world;
  void main() {
    v_world = a_world;
    vec2 screen = (a_world - u_camera) * u_zoom + u_resolution * 0.5;
    vec2 clip = (screen / u_resolution) * 2.0 - 1.0;
    clip.y = -clip.y;
    gl_Position = vec4(clip, 0.0, 1.0);
  }`;

  const FRAG_SRC = `#version 300 es
  precision highp float;
  in vec2 v_world;
  out vec4 outColor;
  #define MAX_LIGHTS 8
  #define MAX_OCCLUDERS 16
  uniform int   u_lightCount;
  uniform vec2  u_lights[MAX_LIGHTS];
  uniform float u_radius[MAX_LIGHTS];
  uniform float u_intensity[MAX_LIGHTS];
  uniform vec3  u_color[MAX_LIGHTS];
  uniform float u_softness[MAX_LIGHTS];
  uniform float u_ambient;
  uniform vec3  u_ambientColor;
  uniform int   u_occluderCount;
  uniform vec4  u_occluders[MAX_OCCLUDERS];
  bool rayHitsBox(vec2 from, vec2 dir, vec2 to, vec4 box) {
    vec2 bmin = box.xy - box.zw * 0.5;
    vec2 bmax = box.xy + box.zw * 0.5;
    vec2 invDir = 1.0 / (dir + vec2(0.00001));
    vec2 t1 = (bmin - from) * invDir;
    vec2 t2 = (bmax - from) * invDir;
    vec2 tmin = min(t1, t2);
    vec2 tmax = max(t1, t2);
    float tNear = max(max(tmin.x, tmin.y), 0.0);
    float tFar  = min(min(tmax.x, tmax.y), length(to - from));
    return tNear < tFar;
  }
  void main() {
    vec3 col = u_ambientColor * (1.0 - u_ambient);
    for (int i = 0; i < MAX_LIGHTS; i++) {
      if (i >= u_lightCount) break;
      vec2 toLight = v_world - u_lights[i];
      float dist = length(toLight);
      float r = u_radius[i];
      if (dist >= r) continue;
      vec2 dirToPixel = normalize(-toLight);
      bool blocked = false;
      for (int j = 0; j < MAX_OCCLUDERS; j++) {
        if (j >= u_occluderCount) break;
        if (rayHitsBox(u_lights[i], dirToPixel, v_world, u_occluders[j])) { blocked = true; break; }
      }
      if (blocked) continue;
      float t = 1.0 - dist / r;
      float atten = smoothstep(0.0, 1.0, t);
      float soft = mix(0.0, 0.85, u_softness[i]);
      float edge = smoothstep(0.0, 1.0 - soft + 0.0001, t);
      col += u_color[i] * u_intensity[i] * atten * edge;
    }
    outColor = vec4(col, 1.0);
  }`;

  const ShadowRenderer = {
    _canvas: null, _gl: null, _prog: null, _vbo: null, _vao: null,
    _loc: {}, _ready: false, _maxLights: 8, _maxOccluders: 16,

    init() {
      if (this._ready) return true;
      const c = document.createElement("canvas");
      const gl = c.getContext("webgl2", {
        alpha: true, premultipliedAlpha: false, antialias: false, preserveDrawingBuffer: true
      });
      if (!gl) { console.warn("[Lighting] WebGL2 недоступен."); return false; }
      this._canvas = c; this._gl = gl;
      const vs = this._compile(gl.VERTEX_SHADER, VERT_SRC);
      const fs = this._compile(gl.FRAGMENT_SHADER, FRAG_SRC);
      if (!vs || !fs) return false;
      const prog = gl.createProgram();
      gl.attachShader(prog, vs); gl.attachShader(prog, fs); gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) { console.error("[Lighting]", gl.getProgramInfoLog(prog)); return false; }
      this._prog = prog;
      this._loc = {
        a_world: gl.getAttribLocation(prog, "a_world"),
        u_resolution: gl.getUniformLocation(prog, "u_resolution"),
        u_camera: gl.getUniformLocation(prog, "u_camera"),
        u_zoom: gl.getUniformLocation(prog, "u_zoom"),
        u_lightCount: gl.getUniformLocation(prog, "u_lightCount"),
        u_lights: gl.getUniformLocation(prog, "u_lights"),
        u_radius: gl.getUniformLocation(prog, "u_radius"),
        u_intensity: gl.getUniformLocation(prog, "u_intensity"),
        u_color: gl.getUniformLocation(prog, "u_color"),
        u_softness: gl.getUniformLocation(prog, "u_softness"),
        u_ambient: gl.getUniformLocation(prog, "u_ambient"),
        u_ambientColor: gl.getUniformLocation(prog, "u_ambientColor"),
        u_occluderCount: gl.getUniformLocation(prog, "u_occluderCount"),
        u_occluders: gl.getUniformLocation(prog, "u_occluders")
      };
      this._vbo = gl.createBuffer();
      this._vao = gl.createVertexArray();
      gl.bindVertexArray(this._vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, this._vbo);
      gl.enableVertexAttribArray(this._loc.a_world);
      gl.vertexAttribPointer(this._loc.a_world, 2, gl.FLOAT, false, 0, 0);
      gl.bindVertexArray(null);
      this._ready = true;
      return true;
    },

    _compile(type, src) {
      const gl = this._gl;
      const s = gl.createShader(type);
      gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { console.error("[Lighting]", gl.getShaderInfoLog(s)); return null; }
      return s;
    },

    isReady() { return this._ready; },

    render({ darkness, lights, occluders, camera, canvasWidth, canvasHeight, targetCtx }) {
      if (!this._ready && !this.init()) return;
      const L = lights.slice(0, this._maxLights);
      const lightCount = L.length;
      const occCount = Math.min(occluders.length, this._maxOccluders);
      const gl = this._gl;
      const c  = this._canvas;
      if (c.width !== canvasWidth || c.height !== canvasHeight) {
        c.width  = canvasWidth; c.height = canvasHeight;
        gl.viewport(0, 0, canvasWidth, canvasHeight);
      }
      const halfW = canvasWidth  / (2 * camera.zoom);
      const halfH = canvasHeight / (2 * camera.zoom);
      const wx0 = camera.x - halfW, wx1 = camera.x + halfW;
      const wy0 = camera.y - halfH, wy1 = camera.y + halfH;
      const verts = new Float32Array([wx0, wy0, wx1, wy0, wx0, wy1, wx0, wy1, wx1, wy0, wx1, wy1]);
      gl.bindVertexArray(this._vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, this._vbo);
      gl.bufferData(gl.ARRAY_BUFFER, verts, gl.DYNAMIC_DRAW);
      gl.vertexAttribPointer(this._loc.a_world, 2, gl.FLOAT, false, 0, 0);
      gl.useProgram(this._prog);
      gl.uniform2f(this._loc.u_resolution, canvasWidth, canvasHeight);
      gl.uniform2f(this._loc.u_camera, camera.x, camera.y);
      gl.uniform1f(this._loc.u_zoom, camera.zoom);
      gl.uniform1i(this._loc.u_lightCount, lightCount);
      gl.uniform1i(this._loc.u_occluderCount, occCount);
      gl.uniform1f(this._loc.u_ambient, darkness);
      gl.uniform3f(this._loc.u_ambientColor, 0.02, 0.03, 0.06);
      const lightPos = new Float32Array(this._maxLights * 2);
      const radii    = new Float32Array(this._maxLights);
      const intens   = new Float32Array(this._maxLights);
      const colors   = new Float32Array(this._maxLights * 3);
      const softs    = new Float32Array(this._maxLights);
      for (let i = 0; i < lightCount; i++) {
        const l = L[i];
        lightPos[i * 2] = l.x; lightPos[i * 2 + 1] = l.y;
        radii[i] = l.radius; intens[i] = l.intensity;
        softs[i] = Math.max(0, Math.min(1, l.softness ?? 0.5));
        const [r, g, b] = this._parseColor(l.rgba);
        colors[i * 3] = r; colors[i * 3 + 1] = g; colors[i * 3 + 2] = b;
      }
      gl.uniform2fv(this._loc.u_lights, lightPos);
      gl.uniform1fv(this._loc.u_radius, radii);
      gl.uniform1fv(this._loc.u_intensity, intens);
      gl.uniform3fv(this._loc.u_color, colors);
      gl.uniform1fv(this._loc.u_softness, softs);
      const occData = new Float32Array(this._maxOccluders * 4);
      for (let i = 0; i < occCount; i++) {
        occData[i * 4] = occluders[i].x;
        occData[i * 4 + 1] = occluders[i].y;
        occData[i * 4 + 2] = occluders[i].w;
        occData[i * 4 + 3] = occluders[i].h;
      }
      gl.uniform4fv(this._loc.u_occluders, occData);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
      gl.bindVertexArray(null);
      targetCtx.save();
      targetCtx.globalCompositeOperation = "multiply";
      targetCtx.globalAlpha = 1;
      targetCtx.drawImage(this._canvas, 0, 0);
      targetCtx.restore();
    },

    _parseColor(str) {
      if (!str) return [0, 0.82, 1];
      if (str[0] === "#") {
        const h = str.length === 4 ? str.replace(/#(.)(.)(.)/, "#$1$1$2$2$3$3") : str;
        const v = parseInt(h.slice(1), 16);
        return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
      }
      const m = str.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
      if (m) return [+m[1] / 255, +m[2] / 255, +m[3] / 255];
      return [0, 0.82, 1];
    }
  };

  window.ShadowRenderer = ShadowRenderer;
})();