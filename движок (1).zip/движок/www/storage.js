// storage.js — сохранение проектов TapEng1ne в IndexedDB
(function () {
  "use strict";
  const DB_NAME = "tapeng1ne";
  const DB_VERSION = 1;
  const STORE = "projects";

  function sanitize(obj) {
    return JSON.parse(JSON.stringify(obj, function (key, val) {
      if (key === "imageElement") return undefined;
      if (key === "_collidingIds") return undefined;
      return val;
    }));
  }

  function openDB() {
    return new Promise(function (resolve, reject) {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = function () {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: "id" });
        }
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error); };
    });
  }

  async function saveProject(id, state) {
    try {
      const db = await openDB();
      const tx = db.transaction(STORE, "readwrite");
      const data = {
        id: id || "default",
        savedAt: Date.now(),
        scenes: sanitize(state.scenes),
        activeSceneIndex: state.activeSceneIndex,
        variables: sanitize(state.variables),
        logicRules: sanitize(state.logicRules),
        bgColor: state.bgColor,
        jsCode: state.jsCode || "",
        pyCode: state.pyCode || "",
        gameJsCode: state.gameJsCode || "",
        codeLanguage: state.codeLanguage || "javascript",
        serverUrl: state.serverUrl || "",
        playerName: state.playerName || "",
        playerColor: state.playerColor || "#00F59B",
        multiplayerExport: !!state.multiplayerExport,
        mpButtonEnabled: state.mpButtonEnabled !== false,
        mpButtonText: state.mpButtonText || "Играть онлайн",
        mpButtonMode: state.mpButtonMode || "both",
        audios: state.audios || [],
        playerSprites: state.playerSprites || { idle: null, walk: null, hide: null }
      };
      tx.objectStore(STORE).put(data);
      return new Promise(function (res, rej) {
        tx.oncomplete = function () { res(true); };
        tx.onerror = function () { rej(tx.error); };
      });
    } catch (e) {
      console.warn("[Storage] save error:", e);
      return false;
    }
  }

  async function loadProject(id) {
    try {
      const db = await openDB();
      const tx = db.transaction(STORE, "readonly");
      return new Promise(function (res) {
        const req = tx.objectStore(STORE).get(id || "default");
        req.onsuccess = function () { res(req.result || null); };
        req.onerror = function () { res(null); };
      });
    } catch (e) {
      return null;
    }
  }

  async function listProjects() {
    try {
      const db = await openDB();
      const tx = db.transaction(STORE, "readonly");
      return new Promise(function (res) {
        const req = tx.objectStore(STORE).getAll();
        req.onsuccess = function () { res(req.result || []); };
        req.onerror = function () { res([]); };
      });
    } catch (e) {
      return [];
    }
  }

  async function deleteProject(id) {
    try {
      const db = await openDB();
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).delete(id);
      return new Promise(function (res) { tx.oncomplete = function () { res(true); }; });
    } catch (e) {
      return false;
    }
  }

  window.TapStorage = {
    saveProject: saveProject,
    loadProject: loadProject,
    listProjects: listProjects,
    deleteProject: deleteProject
  };
})();