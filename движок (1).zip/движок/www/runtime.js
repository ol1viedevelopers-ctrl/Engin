// ============================================================================
// RUNTIME.JS — Движок с API для game.js (The Hunt Edition)
// ============================================================================
(function (global) {
  "use strict";

  const Camera = { x: 0, y: 0, zoom: 1, targetId: null, smoothing: 0.15 };
  const PLAYER_RADIUS = 16;
  
  // Настройки тумана войны
  const SURVIVOR_FOG = 300; // Выжившие видят мало
  const MONSTER_FOG = 450;  // Монстр видит чуть дальше
  const FOG_LOS_STEP = 16;

  const State = {
    canvas: null, ctx: null,
    lightCanvas: null, lightCtx: null,
    fogCanvas: null, fogCtx: null,
    vignetteAlpha: 0,
    project: null,
    activeSceneIndex: 0,
    variables: [],
    logicRules: [],
    activeKeys: {},
    lastTime: 0,
    lastDt: 0,
    tickAcc: 0,
    multiplayer: false,
    netState: null,
    myId: null,
    phase: "playing",
    winner: null,
    joy: { active: false, id: null, baseX: 0, baseY: 0, dx: 0, dy: 0 },
    myPos: { x: 300, y: 300 },
    myPlayer: { id: "local", name: "Игрок", role: "player", alive: true, hidden: false, anim: "idle" },
    _lastSend: 0,
    _lastPlayers: [],
    screen: "game",
    mpButtonText: "Играть онлайн",
    mpButtonMode: "both",
    mpButtonEnabled: true,
    playerName: "Игрок",
    playerColor: "#00F59B",
    roomCode: null,
    isHost: false,
    lobbyPlayers: [],
    playerSprites: null,
    playerSkinImages: null,
    fogEnabled: true,
    cosmetics: { hat: null, bodyColor: "#00F59B" },
    _hatImageCache: null,
    _hatUrlCache: null
  };

  // ============================================================
  // HOOKS
  // ============================================================
  const hooks = new Map();
  function on(event, fn) {
    if (!hooks.has(event)) hooks.set(event, []);
    hooks.get(event).push(fn);
  }
  function emit(event) {
    const args = Array.prototype.slice.call(arguments, 1);
    const list = hooks.get(event) || [];
    for (let i = 0; i < list.length; i++) {
      try { list[i].apply(null, args); }
      catch (e) { console.error("[game]", event, e); }
    }
  }

  // ============================================================
  // AUDIO
  // ============================================================
  const audio = {
    _ctx: null,
    _buffers: new Map(),
    _buses: {},
    _music: null,
    _musicName: null,
    _sounds: {}, // Для остановки циклических звуков (сердцебиение)

    init() {
      if (this._ctx) return this._ctx;
      try {
        this._ctx = new (window.AudioContext || window.webkitAudioContext)();
        const master = this._ctx.createGain();
        master.connect(this._ctx.destination);
        this._buses = { master, music: this._ctx.createGain(), sfx: this._ctx.createGain(), ui: this._ctx.createGain() };
        this._buses.music.connect(master);
        this._buses.sfx.connect(master);
        this._buses.ui.connect(master);
      } catch (e) { console.warn("[Audio]", e); }
      return this._ctx;
    },

    async resume() {
      if (!this._ctx) this.init();
      if (this._ctx && this._ctx.state === "suspended") { try { await this._ctx.resume(); } catch (_) {} }
    },

    async load(name, url) {
      if (this._buffers.has(name)) return this._buffers.get(name);
      if (!this._ctx) this.init();
      if (!this._ctx) return null;
      try {
        const res = await fetch(url);
        if (!res.ok) throw new Error("HTTP " + res.status);
        const arr = await res.arrayBuffer();
        const buf = await this._ctx.decodeAudioData(arr);
        this._buffers.set(name, buf);
        return buf;
      } catch (e) { console.warn("[Audio] load", name, e.message); return null; }
    },

    play(name, opts) {
      opts = opts || {};
      if (!this._ctx) this.init();
      if (!this._ctx) return null;
      const buf = this._buffers.get(name);
      if (!buf) { console.warn("[Audio] not loaded:", name); return null; }
      const src = this._ctx.createBufferSource();
      src.buffer = buf;
      src.loop = !!opts.loop;
      src.playbackRate.value = opts.pitch || 1;
      const gain = this._ctx.createGain();
      gain.gain.value = opts.volume != null ? opts.volume : 1;
      src.connect(gain);
      gain.connect(this._buses[opts.bus || "sfx"] || this._buses.sfx);
      try { src.start(); } catch (_) {}
      
      const handle = { src, gain };
      if (opts.id) this._sounds[opts.id] = handle; // Сохраняем для остановки
      return handle;
    },

    stop(id) {
      if (this._sounds[id]) {
        try { this._sounds[id].src.stop(); } catch (_) {}
        delete this._sounds[id];
      }
    },

    music(name, opts) {
      opts = opts || {};
      if (this._musicName === name && this._music) return;
      this.stopMusic();
      const handle = this.play(name, Object.assign({ bus: "music", loop: true, volume: 0.6 }, opts));
      if (handle) { this._music = handle; this._musicName = name; }
    },

    stopMusic() {
      if (this._music) { try { this._music.src.stop(); } catch (_) {} this._music = null; this._musicName = null; }
    },

    setVolume(bus, v) { if (this._buses[bus]) this._buses[bus].gain.value = v; }
  };

  function _unlockAudio() {
    audio.resume();
    document.removeEventListener("pointerdown", _unlockAudio);
    document.removeEventListener("keydown", _unlockAudio);
  }
  document.addEventListener("pointerdown", _unlockAudio);
  document.addEventListener("keydown", _unlockAudio);

  const save = {
    _prefix: "tapeng1ne_save_",
    set(key, value) { try { localStorage.setItem(this._prefix + key, JSON.stringify(value)); } catch (_) {} },
    get(key, def) {
      try { const v = localStorage.getItem(this._prefix + key); return v !== null ? JSON.parse(v) : def; }
      catch (_) { return def; }
    },
    remove(key) { try { localStorage.removeItem(this._prefix + key); } catch (_) {} }
  };
  global.save = save;

  // ============================================================
  // GAME API
  // ============================================================
  const game = {
    on: on,
    get me() { return State.myPlayer; },
    get players() { return _getAllPlayers(); },
    get objects() { return _scene().objects; },
    get dt() { return State.lastDt; },
    send: function (type, data) { if (window.TapNet) window.TapNet.send("custom", { type, data }); },
    broadcast: function (type, data) { if (window.TapNet) window.TapNet.send("broadcast", { type, data }); },
    
    hide: function () {
      State.myPlayer.hidden = true;
      if (window.TapNet) window.TapNet.send("custom", { type: "_hide", data: { v: true } });
    },
    unhide: function () {
      State.myPlayer.hidden = false;
      if (window.TapNet) window.TapNet.send("custom", { type: "_hide", data: { v: false } });
    },
    
    every: function (ms, fn) { return setInterval(fn, ms); },
    after: function (ms, fn) { return setTimeout(fn, ms); },
    
    sound: function (name, opts) { return audio.play(name, opts); },
    stopSound: function (id) { audio.stop(id); },
    music: function (name, opts) { audio.music(name, opts); },
    stopMusic: function () { audio.stopMusic(); },
    loadSound: function (name, url) { return audio.load(name, url); },
    setVolume: function (bus, v) { audio.setVolume(bus, v); },
    setFog: function (enabled) { State.fogEnabled = !!enabled; },
    
    setPlayerSkin: function (sprites) {
      State.playerSprites = sprites || {};
      State.playerSkinImages = {};
      for (const key in State.playerSprites) {
        if (!State.playerSprites[key]) continue;
        const img = new Image();
        img.src = State.playerSprites[key];
        State.playerSkinImages[key] = img;
      }
    },
    playAnim: function (name) { State.myPlayer.anim = name || "idle"; },

    // Новые API для косметики и эффектов
    setCosmetics: function (data) {
      if (data.hat !== undefined) State.cosmetics.hat = data.hat;
      if (data.bodyColor !== undefined) State.cosmetics.bodyColor = data.bodyColor;
    },
    setVignette: function (alpha) { State.vignetteAlpha = Math.max(0, Math.min(1, alpha)); }
  };
  global.game = game;

  // ============================================================
  // UI API
  // ============================================================
  const ui = {
    overlay: function (id, html) {
      let el = document.getElementById("ui-" + id);
      if (!el) {
        el = document.createElement("div");
        el.id = "ui-" + id;
        el.className = "ui-overlay";
        el.style.cssText =
          "position:fixed;inset:0;z-index:180;display:flex;flex-direction:column;" +
          "align-items:center;justify-content:center;gap:10px;" +
          "background:rgba(3,6,14,0.88);color:#F1F5F9;" +
          "font-family:'Outfit',sans-serif;padding:24px;text-align:center;";
        document.body.appendChild(el);
      }
      el.innerHTML = html || "";
      el.style.display = "flex";
      return el;
    },
    close: function (id) {
      const el = document.getElementById("ui-" + id);
      if (el) el.style.display = "none";
    },
    notify: function (text, type) {
      let box = document.getElementById("ui-notify-box");
      if (!box) {
        box = document.createElement("div");
        box.id = "ui-notify-box";
        box.style.cssText =
          "position:fixed;top:70px;left:50%;transform:translateX(-50%);z-index:190;" +
          "display:flex;flex-direction:column;gap:6px;pointer-events:none;";
        document.body.appendChild(box);
      }
      const n = document.createElement("div");
      const color = type === "danger" ? "#FF4D6D" : type === "warn" ? "#FBBF24" : "#00F59B";
      n.style.cssText =
        "background:rgba(11,17,32,0.95);border:1px solid " + color + ";color:" + color + ";" +
        "border-radius:10px;padding:10px 16px;font-family:'Outfit',sans-serif;" +
        "font-size:13px;font-weight:600;max-width:280px;animation:uiSlideIn 0.2s ease;";
      n.textContent = text;
      box.appendChild(n);
      setTimeout(function () {
        n.style.opacity = "0";
        n.style.transition = "opacity 0.3s";
        setTimeout(function () { n.remove(); }, 300);
      }, 2500);
    },
    button: function (opts) {
      opts = opts || {};
      const btn = document.createElement("button");
      btn.textContent = opts.text || "Кнопка";
      const color = opts.color || "#00F59B";
      btn.style.cssText =
        "min-height:52px;padding:12px 24px;border-radius:14px;" +
        "border:2px solid " + color + ";background:rgba(11,17,32,0.85);color:" + color + ";" +
        "font-family:'Outfit',sans-serif;font-size:16px;font-weight:700;cursor:pointer;" +
        "min-width:200px;margin:4px;";
      if (opts.onClick) btn.onclick = opts.onClick;
      return btn;
    }
  };
  global.ui = ui;

  // ============================================================
  // TELEGRAM API
  // ============================================================
  const tg = {
    _app: null,
    init: function () {
      if (global.Telegram && global.Telegram.WebApp) {
        this._app = global.Telegram.WebApp;
        try { this._app.ready(); this._app.expand(); } catch (_) {}
      }
    },
    user: function () {
      if (!this._app) return { id: "local", first_name: "Игрок" };
      const u = this._app.initDataUnsafe && this._app.initDataUnsafe.user;
      return u || { id: "local", first_name: "Игрок" };
    },
    haptic: function (style) {
      if (!this._app || !this._app.HapticFeedback) return;
      try {
        if (style === "notification") this._app.HapticFeedback.notificationOccurred("success");
        else if (style === "error") this._app.HapticFeedback.notificationOccurred("error");
        else this._app.HapticFeedback.impactOccurred("medium");
      } catch (_) {}
    },
    theme: function () {
      return (this._app && this._app.themeParams && this._app.themeParams.bg_color) || "#060913";
    }
  };
  global.tg = tg;

  // ============================================================
  // START
  // ============================================================
  async function start(canvasId, dataUrl, multiplayer) {
    State.canvas = document.getElementById(canvasId);
    State.ctx = State.canvas.getContext("2d");
    State.lightCanvas = document.createElement("canvas");
    State.lightCtx = State.lightCanvas.getContext("2d");
    State.fogCanvas = document.createElement("canvas");
    State.fogCtx = State.fogCanvas.getContext("2d");
    State.multiplayer = !!multiplayer;

    tg.init();

    const res = await fetch(dataUrl);
    State.project = await res.json();
    State.variables = State.project.variables || [];
    State.logicRules = State.project.logicRules || [];

    for (let s = 0; s < State.project.scenes.length; s++) {
      const scene = State.project.scenes[s];
      for (let i = 0; i < scene.objects.length; i++) {
        const o = scene.objects[i];
        if (o.imageSrc) {
          const img = new Image();
          img.src = o.imageSrc;
          o.imageElement = img;
        }
      }
    }

    const audios = State.project.audios || [];
    for (let i = 0; i < audios.length; i++) {
      const a = audios[i];
      if (a && a.name && a.path) audio.load(a.name, a.path);
    }

    const projectSprites = State.project.playerSprites || {};
    const hasSprites = projectSprites.idle || projectSprites.walk || projectSprites.hide;
    if (hasSprites) {
      State.playerSprites = {};
      State.playerSkinImages = {};
      for (const key of ["idle", "walk", "hide"]) {
        if (projectSprites[key]) {
          State.playerSprites[key] = projectSprites[key];
          const img = new Image();
          img.src = projectSprites[key];
          State.playerSkinImages[key] = img;
        }
      }
    }

    const mpBtn = State.project.mpButton || {};
    State.mpButtonEnabled = mpBtn.enabled !== false;
    State.mpButtonText = mpBtn.text || "Играть онлайн";
    State.mpButtonMode = mpBtn.mode || "both";

    const tgUser = tg.user();
    State.playerName = State.project.playerName || tgUser.first_name || "Игрок";
    State.playerColor = State.project.playerColor || "#00F59B";

    State.myPos = { x: 300, y: 300 };
    State.myId = "local";

    _bindInput();
    _resize();
    global.addEventListener("resize", _resize);

    if (State.multiplayer) {
      State.screen = "menu";
      await _initMultiplayer();
      _bindMobileControls();
      _buildHUD();
      _buildPauseButton();
    } else {
      State.screen = "game";
      State.myPos = _findSpawn();
      emit("start");
    }

    State.lastTime = performance.now();
    requestAnimationFrame(_loop);
  }

  // ============================================================
  // MULTIPLAYER
  // ============================================================
  async function _initMultiplayer() {
    if (!window.TapNet) {
      console.warn("[Runtime] net-client.js не загружен");
      State.multiplayer = false;
      State.screen = "game";
      State.myPos = _findSpawn();
      emit("start");
      return;
    }
    const serverUrl = State.project.serverUrl || "wss://localhost:2567";

    try {
      await window.TapNet.connect(serverUrl);
    } catch (e) {
      console.error("[Runtime] MP connect:", e);
      alert("Сервер недоступен: " + e.message);
      State.multiplayer = false;
      State.screen = "game";
      State.myPos = _findSpawn();
      emit("start");
      return;
    }

    window.TapNet.on("stateChange", function (netState) {
      State.netState = netState;

      if (netState.players && netState.players.get) {
        const me = netState.players.get(State.myId);
        if (me) {
          const wasAlive = State.myPlayer.alive;
          State.myPlayer = {
            id: State.myId,
            name: me.name || "Игрок",
            role: me.role || "player",
            alive: me.alive !== false,
            hidden: me.hidden === true,
            color: me.color || "#00F59B",
            anim: State.myPlayer.anim || "idle"
          };
          if (wasAlive && !State.myPlayer.alive) emit("died");
        }
      }
      if (netState.phase) State.phase = netState.phase;
      State.isHost = netState.hostId === State.myId;

      const current = _getAllPlayers();
      const prevIds = State._lastPlayers.map(function (p) { return p.id; });
      const currIds = current.map(function (p) { return p.id; });
      for (let i = 0; i < current.length; i++) {
        if (prevIds.indexOf(current[i].id) === -1 && current[i].id !== State.myId) {
          emit("playerJoin", current[i]);
        }
      }
      for (let i = 0; i < State._lastPlayers.length; i++) {
        if (currIds.indexOf(State._lastPlayers[i].id) === -1) {
          emit("playerLeave", State._lastPlayers[i]);
        }
      }
      State._lastPlayers = current;

      State.lobbyPlayers = current;
      if (State.screen === "lobby") _renderLobby();

      if (netState.phase === "ended" && State.screen === "game") {
        State.screen = "ended";
        State.winner = netState.winner;
        emit("end", { winner: netState.winner });
      }
    });

    window.TapNet.on("started", function () {
      State.phase = "playing";
      State.winner = null;
      State.screen = "game";
      _hideOverlay("mp-menu-overlay");

      if (State.netState && State.netState.players && State.netState.players.get) {
        const me = State.netState.players.get(State.myId);
        if (me) State.myPos = { x: me.x, y: me.y };
        else State.myPos = _findSpawn();
      } else {
        State.myPos = _findSpawn();
      }

      _sendPos();
      emit("start");
    });

    window.TapNet.on("ended", function (data) {
      if (State.screen === "ended") return;
      State.winner = data.winner;
      State.phase = "ended";
      State.screen = "ended";
      emit("end", data);
    });

    window.TapNet.on("net", function (msg) {
      if (!msg || !msg.type) return;
      if (msg.type === "_hide") {
        State.myPlayer.hidden = !!msg.data.v;
        return;
      }
      emit("net", msg.type, msg.data, msg.from);
    });

    window.TapNet.on("error", function (data) {
      alert(data.message || "Ошибка мультиплеера");
    });

    _buildMenuOverlay();
  }

  function _hideOverlay(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
  }

  function _findSpawn() {
    const objs = _scene().objects;
    const spawns = objs.filter(function (o) { return o.type === "spawnPoint"; });
    if (spawns.length === 0) return { x: 300, y: 300 };
    const sp = spawns[Math.floor(Math.random() * spawns.length)];
    return { x: sp.x, y: sp.y };
  }

  function _collectSpawns() {
    const objs = _scene().objects;
    const arr = [];
    for (let i = 0; i < objs.length; i++) {
      const o = objs[i];
      if (o.type === "spawnPoint") arr.push({ x: Math.round(o.x), y: Math.round(o.y) });
    }
    return arr;
  }

  function _getAllPlayers() {
    if (!State.netState || !State.netState.players) return [];
    const arr = [];
    State.netState.players.forEach(function (v, k) {
      arr.push({
        id: k, name: v.name, x: v.x, y: v.y, color: v.color,
        alive: v.alive, hidden: v.hidden, role: v.role, custom: _parseJson(v.customJson)
      });
    });
    return arr;
  }

  function _parseJson(s) {
    try { return JSON.parse(s || "{}"); } catch (_) { return {}; }
  }

  function _sendPos() {
    if (!State.multiplayer || State.phase !== "playing" || !State.myPlayer.alive) return;
    if (State.screen !== "game") return;
    if (Date.now() - State._lastSend > 100) {
      State._lastSend = Date.now();
      if (window.TapNet) {
        window.TapNet.send("move", {
          x: Math.round(State.myPos.x),
          y: Math.round(State.myPos.y)
        });
      }
    }
  }

  // ============================================================
  // FOG OF WAR & VIGNETTE
  // ============================================================
  function _canSeePlayer(tx, ty) {
    if (State.myPlayer.role === "monster") return true;
    const dx = tx - State.myPos.x;
    const dy = ty - State.myPos.y;
    const dist = Math.hypot(dx, dy);
    
    const maxRadius = State.myPlayer.role === "monster" ? MONSTER_FOG : SURVIVOR_FOG;
    if (dist > maxRadius) return false;
    if (dist < 24) return true;

    const objs = _scene().objects;
    const steps = Math.max(2, Math.ceil(dist / FOG_LOS_STEP));
    for (let s = 1; s < steps; s++) {
      const t = s / steps;
      const px = State.myPos.x + dx * t;
      const py = State.myPos.y + dy * t;
      for (let i = 0; i < objs.length; i++) {
        const o = objs[i];
        if (!o.solid) continue;
        if (o.type === "spawnPoint" || o.type === "trigger") continue;
        const hw = o.width / 2;
        const hh = o.height / 2;
        if (px >= o.x - hw && px <= o.x + hw && py >= o.y - hh && py <= o.y + hh) {
          return false;
        }
      }
    }
    return true;
  }

  function _renderFog() {
    if (!State.fogEnabled) return;
    if (State.screen !== "game") return;
    // Призраки видят всё
    if (State.myPlayer.alive === false) return;

    const radius = State.myPlayer.role === "monster" ? MONSTER_FOG : SURVIVOR_FOG;
    const w = State.canvas.width;
    const h = State.canvas.height;
    const fc = State.fogCanvas;
    const fctx = State.fogCtx;
    if (fc.width !== w || fc.height !== h) {
      fc.width = w; fc.height = h;
    }

    fctx.clearRect(0, 0, w, h);
    fctx.fillStyle = "rgba(2,4,10,0.95)";
    fctx.fillRect(0, 0, w, h);

    fctx.globalCompositeOperation = "destination-out";
    const cx = (State.myPos.x - Camera.x) * Camera.zoom + w * 0.5;
    const cy = (State.myPos.y - Camera.y) * Camera.zoom + h * 0.5;
    const r = radius * Camera.zoom;
    const g = fctx.createRadialGradient(cx, cy, 0, cx, cy, r);
    g.addColorStop(0, "rgba(0,0,0,1)");
    g.addColorStop(0.55, "rgba(0,0,0,1)");
    g.addColorStop(0.85, "rgba(0,0,0,0.5)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    fctx.fillStyle = g;
    fctx.beginPath();
    fctx.arc(cx, cy, r, 0, Math.PI * 2);
    fctx.fill();
    fctx.globalCompositeOperation = "source-over";

    State.ctx.drawImage(fc, 0, 0);

    // Кровавая виньетка страха
    if (State.vignetteAlpha > 0) {
      const vg = State.ctx.createRadialGradient(w/2, h/2, h*0.3, w/2, h/2, h*0.8);
      vg.addColorStop(0, "rgba(255,0,0,0)");
      vg.addColorStop(1, `rgba(255,0,0,${State.vignetteAlpha})`);
      State.ctx.fillStyle = vg;
      State.ctx.fillRect(0, 0, w, h);
    }
  }

  // ============================================================
  // LOBBY UI
  // ============================================================
  function _buildMenuOverlay() {
    if (document.getElementById("mp-menu-overlay")) return;
    const overlay = document.createElement("div");
    overlay.id = "mp-menu-overlay";
    overlay.style.cssText =
      "position:fixed;inset:0;z-index:150;display:flex;flex-direction:column;" +
      "align-items:center;justify-content:center;" +
      "background:radial-gradient(circle at 50% 30%, rgba(11,17,32,0.9), rgba(3,6,14,0.98));" +
      "font-family:'Outfit',sans-serif;color:#F1F5F9;padding:24px;text-align:center;";
    overlay.innerHTML = '<h1 style="font-size:32px;font-weight:800;margin-bottom:16px;' +
      'background:linear-gradient(135deg,#00F59B,#00D2FF);-webkit-background-clip:text;' +
      'background-clip:text;-webkit-text-fill-color:transparent;">' + (State.mpButtonText || "МУЛЬТИПЛЕЕР") + '</h1>' +
      '<div id="mp-menu-content"></div>';
    document.body.appendChild(overlay);
    _renderMenuContent();
  }

  function _renderMenuContent() {
    const content = document.getElementById("mp-menu-content");
    if (!content) return;

    if (State.screen === "menu") {
      content.innerHTML =
        '<button id="mp-btn-main" style="' + _btnStyle("#00F59B", "big") + '">' +
        State.mpButtonText + '</button>';
      document.getElementById("mp-btn-main").onclick = function () {
        State.screen = "create_join"; _renderMenuContent();
      };
      return;
    }

    if (State.screen === "create_join") {
      let html = '<div style="display:flex;flex-direction:column;gap:12px;max-width:320px;width:100%;">';
      if (State.mpButtonMode === "both" || State.mpButtonMode === "create") {
        html += '<button id="mp-btn-create" style="' + _btnStyle("#00F59B") + '">➕ Создать комнату</button>';
      }
      if (State.mpButtonMode === "both" || State.mpButtonMode === "join") {
        html += '<button id="mp-btn-join" style="' + _btnStyle("#00D2FF") + '">🔑 Войти по коду</button>';
      }
      html += '<button id="mp-btn-back" style="' + _btnStyle("#94A3B8") + '">← Назад</button>';
      html += '</div>';
      content.innerHTML = html;
      const cr = document.getElementById("mp-btn-create");
      if (cr) cr.onclick = _createRoom;
      const jn = document.getElementById("mp-btn-join");
      if (jn) jn.onclick = _showJoinInput;
      document.getElementById("mp-btn-back").onclick = function () {
        State.screen = "menu"; _renderMenuContent();
      };
      return;
    }
  }

  function _showJoinInput() {
    const content = document.getElementById("mp-menu-content");
    if (!content) return;
    content.innerHTML =
      '<div style="display:flex;flex-direction:column;gap:12px;max-width:320px;width:100%;">' +
      '<label style="font-size:13px;color:#94A3B8;text-align:left;">Код комнаты</label>' +
      '<input id="mp-join-code" type="text" placeholder="XXXXXX" style="' + _inputStyle() + '" />' +
      '<button id="mp-btn-join-ok" style="' + _btnStyle("#00F59B") + '">Войти</button>' +
      '<button id="mp-btn-back" style="' + _btnStyle("#94A3B8") + '">← Назад</button>' +
      '</div>';
    const inp = document.getElementById("mp-join-code");
    inp.focus();
    document.getElementById("mp-btn-back").onclick = function () {
      State.screen = "create_join"; _renderMenuContent();
    };
    document.getElementById("mp-btn-join-ok").onclick = function () {
      const code = (inp.value || "").trim();
      if (code) _joinRoom(code);
    };
  }

  async function _createRoom() {
    try {
      const code = await window.TapNet.host({ name: State.playerName, color: State.playerColor });
      State.myId = window.TapNet.getMyId();
      State.roomCode = code;
      State.screen = "lobby";
      _renderLobby();
    } catch (e) {
      alert("Не удалось создать комнату: " + e.message);
    }
  }

  async function _joinRoom(code) {
    try {
      await window.TapNet.joinRoom(code, { name: State.playerName, color: State.playerColor });
      State.myId = window.TapNet.getMyId();
      State.roomCode = code;
      State.screen = "lobby";
      _renderLobby();
    } catch (e) {
      alert("Не удалось войти: " + e.message);
    }
  }

  function _renderLobby() {
    const content = document.getElementById("mp-menu-content");
    if (!content) return;
    let playersHtml = "";
    for (let i = 0; i < State.lobbyPlayers.length; i++) {
      const p = State.lobbyPlayers[i];
      playersHtml +=
        '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;' +
        'background:rgba(17,26,46,0.8);border-radius:10px;border:1px solid rgba(0,245,155,0.2);">' +
        '<div style="width:16px;height:16px;border-radius:50%;background:' +
        (p.color || "#00F59B") + ';"></div>' +
        '<span style="flex:1;font-size:14px;text-align:left;">' + (p.name || "Игрок") +
        (p.id === State.myId ? " (Вы)" : "") + '</span></div>';
    }
    let html =
      '<div style="display:flex;flex-direction:column;gap:14px;max-width:360px;width:100%;">' +
      '<div style="padding:16px;background:rgba(17,26,46,0.9);border-radius:14px;' +
      'border:1px solid rgba(0,245,155,0.4);text-align:center;">' +
      '<div style="font-size:12px;color:#94A3B8;margin-bottom:4px;">Код комнаты</div>' +
      '<div style="font-size:26px;font-weight:800;color:#00F59B;' +
      'font-family:\'JetBrains Mono\',monospace;letter-spacing:0.1em;">' +
      State.roomCode + '</div></div>' +
      '<div style="font-size:13px;color:#94A3B8;text-align:left;">Игроков: ' +
      State.lobbyPlayers.length + '</div>' +
      '<div style="display:flex;flex-direction:column;gap:6px;max-height:240px;overflow-y:auto;">' +
      playersHtml + '</div>';
    if (State.isHost) {
      html += '<button id="mp-btn-start" style="' + _btnStyle("#00F59B") + '">▶ Начать игру</button>';
    } else {
      html += '<div style="text-align:center;color:#94A3B8;font-size:13px;">Ожидание хоста...</div>';
    }
    html += '</div>';
    content.innerHTML = html;
    const startBtn = document.getElementById("mp-btn-start");
    if (startBtn) startBtn.onclick = function () {
      const spawns = _collectSpawns();
      window.TapNet.send("startGame", { spawns: spawns });
    };
  }

  function _btnStyle(color, size) {
    const big = size === "big";
    return (
      "min-height:" + (big ? "72" : "52") + "px;" +
      "padding:" + (big ? "16px 40px" : "12px 24px") + ";" +
      "border-radius:14px;border:2px solid " + color + ";" +
      "background:rgba(11,17,32,0.85);color:" + color + ";" +
      "font-family:'Outfit',sans-serif;font-size:" + (big ? "20" : "15") + "px;" +
      "font-weight:700;cursor:pointer;" +
      (big ? "min-width:240px;" : "width:100%;")
    );
  }
  function _inputStyle() {
    return (
      "min-height:52px;padding:12px 16px;border-radius:12px;" +
      "border:1px solid rgba(0,245,155,0.4);background:#080D1A;color:#F1F5F9;" +
      "font-family:'JetBrains Mono',monospace;font-size:18px;text-align:center;" +
      "outline:none;letter-spacing:0.15em;"
    );
  }

  function _buildPauseButton() {
    if (document.getElementById("mp-pause")) return;
    const btn = document.createElement("button");
    btn.id = "mp-pause";
    btn.textContent = "⏸";
    btn.style.cssText =
      "position:fixed;top:16px;right:16px;width:46px;height:46px;" +
      "border-radius:50%;border:2px solid #00F59B;background:rgba(11,17,32,0.88);" +
      "color:#00F59B;font-size:20px;font-weight:700;cursor:pointer;z-index:60;" +
      "display:none;align-items:center;justify-content:center;line-height:1;";
    document.body.appendChild(btn);
    btn.onclick = _togglePause;
  }

  function _togglePause() {
    const existing = document.getElementById("ui-pause");
    if (existing && existing.style.display !== "none") {
      ui.close("pause");
      return;
    }
    ui.overlay("pause",
      '<div style="font-size:24px;margin-bottom:20px;color:#FBBF24;">⏸ ПАУЗА</div>' +
      '<div style="display:flex;flex-direction:column;gap:10px;max-width:280px;width:100%;">' +
      '<button id="pause-resume" style="' + _btnStyle("#00F59B") + '">▶ Продолжить</button>' +
      '<button id="pause-exit" style="' + _btnStyle("#FF4D6D") + '">✕ Выйти в меню</button>' +
      '</div>'
    );
    document.getElementById("pause-resume").onclick = function () { ui.close("pause"); };
    document.getElementById("pause-exit").onclick = function () {
      if (window.TapNet) { try { window.TapNet.leave(); } catch (_) {} }
      setTimeout(function () { window.location.reload(); }, 300);
    };
  }

  // ============================================================
  // INPUT
  // ============================================================
  function _bindInput() {
    global.addEventListener("keydown", function (e) {
      State.activeKeys[e.code] = true;
      if (State.screen === "game" && e.code === "KeyE") _interact();
    });
    global.addEventListener("keyup", function (e) {
      State.activeKeys[e.code] = false;
    });
    State.canvas.addEventListener("pointerdown", function (e) {
      if (State.screen !== "game") return;
      if (State.multiplayer && State.phase === "playing") return;
      const rect = State.canvas.getBoundingClientRect();
      const sx = e.clientX - rect.left, sy = e.clientY - rect.top;
      const wx = (sx - State.canvas.width * 0.5) / Camera.zoom + Camera.x;
      const wy = (sy - State.canvas.height * 0.5) / Camera.zoom + Camera.y;
      const objs = _scene().objects;
      for (let i = objs.length - 1; i >= 0; i--) {
        const o = objs[i];
        if (Math.abs(wx - o.x) < o.width * 0.5 && Math.abs(wy - o.y) < o.height * 0.5) {
          _interactObject(o);
          break;
        }
      }
    });
  }

  function _interactObject(obj) {
    if (!obj) return;
    emit("interact", State.myPlayer, obj);
  }

  function _interact() {
    const objs = _scene().objects;
    let nearest = null, nearestD = 80;
    for (let i = 0; i < objs.length; i++) {
      const o = objs[i];
      if (o.type === "wall" || o.type === "platform" || o.type === "spawnPoint") continue;
      const d = Math.hypot(o.x - State.myPos.x, o.y - State.myPos.y);
      if (d < nearestD) { nearestD = d; nearest = o; }
    }
    if (nearest) _interactObject(nearest);
  }

  function _bindMobileControls() {
    const canvas = State.canvas;
    canvas.addEventListener("pointerdown", function (e) {
      if (e.pointerType === "mouse") return;
      if (State.screen !== "game") return;
      // Призраки тоже могут двигаться
      if (State.phase !== "playing") return;
      if (e.clientX > global.innerWidth * 0.5) return;
      State.joy.active = true;
      State.joy.id = e.pointerId;
      State.joy.baseX = e.clientX;
      State.joy.baseY = e.clientY;
      State.joy.dx = 0; State.joy.dy = 0;
      try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
    });
    canvas.addEventListener("pointermove", function (e) {
      if (!State.joy.active || e.pointerId !== State.joy.id) return;
      const dx = e.clientX - State.joy.baseX;
      const dy = e.clientY - State.joy.baseY;
      const max = 60;
      const len = Math.hypot(dx, dy);
      const k = len > max ? max / len : 1;
      State.joy.dx = dx * k;
      State.joy.dy = dy * k;
    });
    function releaseJoy(e) {
      if (e.pointerId === State.joy.id) {
        State.joy.active = false;
        State.joy.id = null;
        State.joy.dx = 0; State.joy.dy = 0;
      }
    }
    canvas.addEventListener("pointerup", releaseJoy);
    canvas.addEventListener("pointercancel", releaseJoy);

    _buildActionButtons();
  }

  function _buildActionButtons() {
    if (document.getElementById("mp-actions")) return;
    const root = document.createElement("div");
    root.id = "mp-actions";
    root.style.cssText =
      "position:fixed;right:16px;bottom:16px;display:none;flex-direction:column;gap:10px;z-index:50;";
    root.innerHTML = '<button id="mp-btn-use" class="mp-action-btn">🛠</button>';
    document.body.appendChild(root);

    const style = document.createElement("style");
    style.textContent =
      ".mp-action-btn{width:100px;height:100px;border-radius:50%;" +
      "border:2px solid #00F59B;background:rgba(11,17,32,0.85);color:#00F59B;" +
      "font-family:Outfit,sans-serif;font-size:28px;font-weight:700;cursor:pointer;" +
      "display:flex;align-items:center;justify-content:center;}" +
      ".mp-action-btn:active{transform:scale(0.92);}";
    document.head.appendChild(style);

    document.getElementById("mp-btn-use").onclick = function() {
      _interact();
      window.TapInput = window.TapInput || {};
      window.TapInput.usePressed = true;
    };

    setInterval(function () {
      if (root) root.style.display = State.screen === "game" ? "flex" : "none";
    }, 300);
  }

  // ============================================================
  // COLLISIONS
  // ============================================================
  function _canMoveTo(x, y, radius) {
    // Призраки пролетают сквозь стены
    if (State.myPlayer.alive === false) return true;

    const objs = _scene().objects;
    for (let i = 0; i < objs.length; i++) {
      const o = objs[i];
      if (!o.solid) continue;
      if (o.type === "spawnPoint" || o.type === "trigger") continue;
      const hw = (o.width + radius * 2) * 0.5;
      const hh = (o.height + radius * 2) * 0.5;
      if (Math.abs(x - o.x) < hw && Math.abs(y - o.y) < hh) return false;
    }
    return true;
  }

  // ============================================================
  // LOOP
  // ============================================================
  function _loop(now) {
    const dt = Math.min(0.05, (now - State.lastTime) / 1000);
    State.lastTime = now;
    State.lastDt = dt;
    _update(dt);
    _render(now / 1000);
    _renderHUD();
    if (State.screen === "game") {
      try { emit("update", dt); } catch (e) { console.error("[game.update]", e); }
    }
    requestAnimationFrame(_loop);
  }

  function _update(dt) {
    const objs = _scene().objects;
    State.tickAcc += dt;
    if (State.tickAcc >= 1) { State.tickAcc = 0; _runLogic("onTick", null); }

    if (State.multiplayer) {
      if (State.screen === "game" && State.phase === "playing") {
        // Даже мертвые (призраки) двигаются
        const sp = State.myPlayer.role === "monster" ? 210 : 180;
        let mx = 0, my = 0;
        if (State.joy.active) {
          const len = Math.hypot(State.joy.dx, State.joy.dy);
          if (len > 8) { mx = State.joy.dx / 60; my = State.joy.dy / 60; }
        }
        if (State.activeKeys["ArrowLeft"] || State.activeKeys["KeyA"]) mx -= 1;
        if (State.activeKeys["ArrowRight"] || State.activeKeys["KeyD"]) mx += 1;
        if (State.activeKeys["ArrowUp"] || State.activeKeys["KeyW"]) my -= 1;
        if (State.activeKeys["ArrowDown"] || State.activeKeys["KeyS"]) my += 1;
        const mag = Math.hypot(mx, my);
        if (mag > 1) { mx /= mag; my /= mag; }
        
        if (mag > 0.05) {
          const nx = State.myPos.x + mx * sp * dt;
          const ny = State.myPos.y + my * sp * dt;
          if (_canMoveTo(nx, ny, PLAYER_RADIUS)) {
            State.myPos.x = nx; State.myPos.y = ny;
          } else if (_canMoveTo(nx, State.myPos.y, PLAYER_RADIUS)) {
            State.myPos.x = nx;
          } else if (_canMoveTo(State.myPos.x, ny, PLAYER_RADIUS)) {
            State.myPos.y = ny;
          }
          if (State.myPlayer.anim === "idle") State.myPlayer.anim = "walk";
        } else {
          if (State.myPlayer.anim === "walk") State.myPlayer.anim = "idle";
        }
        if (State.myPlayer.alive) _sendPos();
      }
      Camera.x += (State.myPos.x - Camera.x) * Camera.smoothing;
      Camera.y += (State.myPos.y - Camera.y) * Camera.smoothing;
    } else {
      // Одиночный режим (без изменений)
      for (let i = 0; i < objs.length; i++) {
        const o = objs[i];
        if (o.controllable) {
          const sp = 240;
          if (State.activeKeys["ArrowLeft"] || State.activeKeys["KeyA"]) { o.x -= sp * dt; o.anim = "walk"; }
          if (State.activeKeys["ArrowRight"] || State.activeKeys["KeyD"]) { o.x += sp * dt; o.anim = "walk"; }
          if ((State.activeKeys["ArrowUp"] || State.activeKeys["KeyW"] || State.activeKeys["Space"]) && Math.abs(o.vy || 0) < 5) {
            o.vy = -440; o.anim = "jump";
          }
        }
      }
      const target = objs.find(function (o) { return o.cameraFollow; });
      if (target) {
        Camera.x += (target.x - Camera.x) * Camera.smoothing;
        Camera.y += (target.y - Camera.y) * Camera.smoothing;
      }
    }

    const lvl = State.project.level || { width: 1920, height: 1080 };
    const halfW = State.canvas.width / (2 * Camera.zoom);
    const halfH = State.canvas.height / (2 * Camera.zoom);
    Camera.x = Math.max(halfW, Math.min(lvl.width - halfW, Camera.x));
    Camera.y = Math.max(halfH, Math.min(lvl.height - halfH, Camera.y));
  }

  // ============================================================
  // RENDER
  // ============================================================
  function _render(timeSec) {
    const ctx = State.ctx;
    const scene = _scene();

    ctx.fillStyle = scene.bgColor || "#060913";
    ctx.fillRect(0, 0, State.canvas.width, State.canvas.height);

    ctx.save();
    ctx.translate(State.canvas.width * 0.5, State.canvas.height * 0.5);
    ctx.scale(Camera.zoom, Camera.zoom);
    ctx.translate(-Camera.x, -Camera.y);

    for (let i = 0; i < scene.objects.length; i++) {
      const o = scene.objects[i];
      if (o.type === "light" || o.type === "spawnPoint") continue;
      _drawObject(ctx, o, timeSec);
    }

    if (State.multiplayer && State.screen === "game") {
      const players = _getAllPlayers();
      for (let i = 0; i < players.length; i++) {
        const p = players[i];
        if (p.id === State.myId) continue;
        if (p.hidden && p.alive) continue;
        if (!_canSeePlayer(p.x, p.y)) continue;
        _drawPlayer(ctx, p, p.color || "#00D2FF", false);
      }
      // Отрисовка себя
      _drawPlayer(ctx, {
        x: State.myPos.x, y: State.myPos.y, name: State.playerName,
        color: State.playerColor, hidden: false, anim: State.myPlayer.anim,
        alive: State.myPlayer.alive
      }, State.playerColor, true);
    }

    ctx.restore();
    _renderLighting(scene);
    if (State.multiplayer) _renderFog();
    _renderJoystick(ctx);
  }

  function _drawPlayer(ctx, p, color, isMe) {
    const r = PLAYER_RADIUS;
    const isGhost = p.alive === false;
    
    // Скины (если загружены)
    if (isMe && State.playerSprites && State.playerSkinImages) {
      const anim = p.anim || "idle";
      const img = State.playerSkinImages[anim] || State.playerSkinImages.idle;
      if (img && img.complete && img.naturalWidth > 0) {
        ctx.save();
        ctx.globalAlpha = isGhost ? 0.4 : 1;
        ctx.drawImage(img, p.x - 24, p.y - 24, 48, 48);
        _drawCosmeticsAndName(ctx, p, isMe, isGhost);
        ctx.restore();
        return;
      }
    }

    // Базовая отрисовка
    ctx.save();
    ctx.globalAlpha = isGhost ? 0.4 : 1;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.fillStyle = isMe ? State.cosmetics.bodyColor : color;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = isGhost ? "#88FFFF" : (isMe ? "#FFFFFF" : "rgba(0,0,0,0.4)");
    ctx.stroke();
    
    // Визор
    ctx.beginPath();
    ctx.ellipse(p.x + 6, p.y - 4, 5, 7, 0, 0, Math.PI * 2);
    ctx.fillStyle = isGhost ? "#88FFFF" : "#E0F7FF";
    ctx.fill();
    
    _drawCosmeticsAndName(ctx, p, isMe, isGhost);
    ctx.restore();
  }

  function _drawCosmeticsAndName(ctx, p, isMe, isGhost) {
    // Шляпа (только для себя в этом примере)
    if (isMe && State.cosmetics.hat) {
      if (State.cosmetics.hat.startsWith("data:image") || State.cosmetics.hat.startsWith("http")) {
        if (State._hatUrlCache !== State.cosmetics.hat) {
           State._hatImageCache = new Image();
           State._hatImageCache.src = State.cosmetics.hat;
           State._hatUrlCache = State.cosmetics.hat;
        }
        if (State._hatImageCache && State._hatImageCache.complete) {
           ctx.drawImage(State._hatImageCache, p.x - 20, p.y - 45, 40, 40);
        }
      } else {
        // Эмодзи
        ctx.font = "24px Arial";
        ctx.textAlign = "center";
        ctx.fillText(State.cosmetics.hat, p.x, p.y - 25);
      }
    }

    // Имя
    ctx.font = "600 12px Outfit, sans-serif";
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fillText(p.name || "", p.x, p.y - 30);
  }

  function _drawObject(ctx, o, t) {
    ctx.save();
    ctx.translate(o.x, o.y);
    ctx.rotate((o.rotation || 0) * Math.PI / 180);
    ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
    if (o.imageElement && o.imageElement.complete) {
      ctx.drawImage(o.imageElement, -o.width / 2, -o.height / 2, o.width, o.height);
    } else {
      ctx.fillStyle = o.color || "#00F59B";
      const shape = o.shape || "rect";
      if (shape === "circle" || shape === "trigger") {
        ctx.beginPath();
        ctx.arc(0, 0, Math.min(o.width, o.height) / 2, 0, Math.PI * 2);
        ctx.fill();
      } else if (shape === "triangle") {
        ctx.beginPath();
        ctx.moveTo(0, -o.height / 2);
        ctx.lineTo(o.width / 2, o.height / 2);
        ctx.lineTo(-o.width / 2, o.height / 2);
        ctx.closePath();
        ctx.fill();
      } else {
        ctx.fillRect(-o.width / 2, -o.height / 2, o.width, o.height);
      }
    }
    ctx.restore();
  }

  function _renderLighting(scene) {
    const darkness = scene.ambientDarkness || 0;
    const lights = scene.objects.filter(function (o) { return o.type === "light"; });
    if (darkness <= 0.005 && lights.length === 0) return;
    const w = State.canvas.width, h = State.canvas.height;
    const lc = State.lightCtx;
    lc.clearRect(0, 0, w, h);
    lc.globalCompositeOperation = "source-over";
    lc.fillStyle = "rgba(2,4,10," + darkness + ")";
    lc.fillRect(0, 0, w, h);
    lc.globalCompositeOperation = "destination-out";
    for (let i = 0; i < lights.length; i++) {
      const l = lights[i];
      const sx = (l.x - Camera.x) * Camera.zoom + w * 0.5;
      const sy = (l.y - Camera.y) * Camera.zoom + h * 0.5;
      const sr = (l.radius || 220) * Camera.zoom;
      const a = l.intensity == null ? 0.9 : l.intensity;
      const g = lc.createRadialGradient(sx, sy, 0, sx, sy, sr);
      g.addColorStop(0, "rgba(0,0,0," + a + ")");
      g.addColorStop(0.55, "rgba(0,0,0," + (a * 0.65) + ")");
      g.addColorStop(1, "rgba(0,0,0,0)");
      lc.fillStyle = g;
      lc.beginPath();
      lc.arc(sx, sy, sr, 0, Math.PI * 2);
      lc.fill();
    }
    State.ctx.drawImage(State.lightCanvas, 0, 0);
  }

  function _renderJoystick(ctx) {
    if (!State.joy.active) return;
    ctx.save();
    const cx = State.joy.baseX, cy = State.joy.baseY;
    ctx.beginPath();
    ctx.arc(cx, cy, 60, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(11,17,32,0.5)";
    ctx.fill();
    ctx.strokeStyle = "rgba(0,245,155,0.5)";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx + State.joy.dx, cy + State.joy.dy, 26, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(0,245,155,0.8)";
    ctx.fill();
    ctx.restore();
  }

  function _buildHUD() {
    if (document.getElementById("mp-hud")) return;
    const hud = document.createElement("div");
    hud.id = "mp-hud";
    hud.style.cssText =
      "position:fixed;top:16px;left:16px;z-index:50;display:none;" +
      "background:rgba(11,17,32,0.9);border:1px solid rgba(0,245,155,0.4);" +
      "border-radius:12px;padding:10px 14px;color:#F1F5F9;" +
      "font-family:'JetBrains Mono',monospace;font-size:12px;line-height:1.5;";
    document.body.appendChild(hud);
  }

  function _renderHUD() {
    if (!State.multiplayer) return;
    const hud = document.getElementById("mp-hud");
    if (!hud) return;

    const pauseBtn = document.getElementById("mp-pause");
    if (pauseBtn) {
      pauseBtn.style.display = (State.screen === "game") ? "flex" : "none";
    }

    if (State.screen !== "game" && State.screen !== "ended") {
      hud.style.display = "none";
      return;
    }
    hud.style.display = "block";
    const players = _getAllPlayers();
    let aliveCount = 0;
    for (let i = 0; i < players.length; i++) if (players[i].alive) aliveCount++;
    let html = "";
    html += "Роль: " + (State.myPlayer.role === "monster" ? "🔪 МОНСТР" : "🏃 ВЫЖИВШИЙ");
    html += "<br>" + (State.myPlayer.alive ? "🟢 Жив" : "👻 Призрак");
    html += "<br>Живых: " + aliveCount + " / " + players.length;
    hud.innerHTML = html;
  }

  // ============================================================
  // LOGIC
  // ============================================================
  function _runLogic(event, trigger) {
    // ... оставляем как было ...
  }
  function _runAction(act, target) {
    // ... оставляем как было ...
  }

  function _scene() {
    return State.project.scenes[State.activeSceneIndex] || State.project.scenes[0];
  }

  function _resize() {
    State.canvas.width = global.innerWidth;
    State.canvas.height = global.innerHeight;
    State.lightCanvas.width = State.canvas.width;
    State.lightCanvas.height = State.canvas.height;
    State.fogCanvas.width = State.canvas.width;
    State.fogCanvas.height = State.canvas.height;
  }

  if (!document.getElementById("ui-anim-style")) {
    const s = document.createElement("style");
    s.id = "ui-anim-style";
    s.textContent = "@keyframes uiSlideIn{from{transform:translateY(-10px);opacity:0}to{transform:translateY(0);opacity:1}}";
    document.head.appendChild(s);
  }

  global.TapRuntime = { start: start, State: State, Camera: Camera };
})(window);