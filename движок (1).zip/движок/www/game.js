// ============================================================
// GAME.JS — The Hunt (Хоррор-прятки)
// ============================================================

let monsterPlayer = null;
let heartbeatInterval = null;
let vignetteTimeout = null;

game.on("start", function () {
  console.log("[Game] Матч начался!");
  
  const isMonster = game.me.role === "monster";
  
  if (isMonster) {
    ui.notify("ТЫ — МОНСТР. Найди и убей всех!", "danger");
    tg.haptic("error");
    game.music("monster_theme", { volume: 0.5 });
  } else {
    ui.notify("Прячься. Не шуми. Выживи 3 минуты.", "warn");
    game.music("horror_ambient", { volume: 0.4 });
  }

  // Включаем локальную косметику (для теста)
  game.setCosmetics({ hat: "🎩" }); 
});

game.on("update", function (dt) {
  if (game.me.role === "monster") {
    // Монстр ищет ближайшую жертву
    let nearestDist = Infinity;
    let target = null;
    
    for (const p of game.players) {
      if (p.role === "survivor" && p.alive) {
        const d = Math.hypot(p.x - game.me.x, p.y - game.me.y);
        if (d < nearestDist) { nearestDist = d; target = p; }
      }
    }

    // Если монстр рядом с жертвой (меньше 80px) — убиваем по клику или кнопке
    if (target && nearestDist < 80) {
      ui.notify("Нажми 🛠 чтобы убить!", "danger");
      // В идеале повесить это на кнопку, но пока так:
      if (window.TapInput && window.TapInput.usePressed) {
         game.send("catch", { targetId: target.id });
         window.TapInput.usePressed = false;
      }
    }

  } else {
    // ВЫЖИВШИЙ
    if (!game.me.alive) return; // Если мертв, логика не работает

    // Ищем ближайшего монстра для эффектов страха
    let distToMonster = Infinity;
    for (const p of game.players) {
      if (p.role === "monster" && p.alive) {
        distToMonster = Math.hypot(p.x - game.me.x, p.y - game.me.y);
        break;
      }
    }

    // Эффект приближения
    if (distToMonster < 400) {
      // Чем ближе, тем сильнее виньетка (от 0 до 0.6)
      const intensity = Math.max(0, 1 - (distToMonster / 400)) * 0.6;
      game.setVignette(intensity);

      // Звук сердца
      if (!heartbeatInterval) {
        game.sound("heartbeat", { loop: true, volume: 0.8 });
        heartbeatInterval = setInterval(() => { tg.haptic(); }, 600);
      }
    } else {
      game.setVignette(0);
      if (heartbeatInterval) {
        game.stopMusic(); // По-хорошему, нужен stopSound, но в движке пока только stopMusic
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
      }
    }
  }
});

// Обработка события "Игрока поймали"
game.on("net", function (type, data, from) {
  if (type === "caught") {
    ui.notify(`💀 ${data.target} был убит!`, "danger");
    game.sound("scream", { volume: 0.8 });
    tg.haptic("error");
  }
});

// Игрок умер и стал призраком
game.on("died", function () {
  ui.notify("Ты стал призраком. Теперь ты можешь летать сквозь стены.", "warn");
  game.setVignette(0);
  game.stopMusic();
  if (heartbeatInterval) clearInterval(heartbeatInterval);
});

game.on("end", function (result) {
  game.stopMusic();
  if (heartbeatInterval) clearInterval(heartbeatInterval);

  const win = result.winner === "survivor";
  ui.overlay("end",
    '<h1 style="font-size:36px;color:' + (win ? "#00F59B" : "#FF4D6D") + ';margin-bottom:20px;">' +
    (win ? "🚪 ВЫ ВЫЖИЛИ" : "💀 МОНСТР ПОБЕДИЛ") + '</h1>' +
    '<button onclick="location.reload()" style="padding:14px 28px;border-radius:12px;border:2px solid #00F59B;background:transparent;color:#00F59B;font-size:16px;font-weight:700;cursor:pointer;">Ещё раз</button>'
  );
});