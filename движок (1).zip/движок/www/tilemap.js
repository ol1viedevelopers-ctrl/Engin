// tilemap.js — тайлмап с чанками
(function () {
  "use strict";

  class TilemapRenderer {
    constructor(scene, ctx) {
      this.scene = scene;
      this.ctx = ctx;
      this.chunkSize = 16;
      this.chunkCache = new Map();
    }
    invalidate() { this.chunkCache.clear(); }
    render(camera, canvasW, canvasH) {
      if (!this.scene.tilemap) return;
      const tm = this.scene.tilemap;
      const ts = tm.tileSize;
      const halfW = canvasW / (2 * camera.zoom);
      const halfH = canvasH / (2 * camera.zoom);
      const startCX = Math.floor((camera.x - halfW) / (this.chunkSize * ts));
      const endCX = Math.ceil((camera.x + halfW) / (this.chunkSize * ts));
      const startCY = Math.floor((camera.y - halfH) / (this.chunkSize * ts));
      const endCY = Math.ceil((camera.y + halfH) / (this.chunkSize * ts));
      for (const layer of tm.layers) {
        if (!layer.visible) continue;
        for (let cy = startCY; cy <= endCY; cy++) {
          for (let cx = startCX; cx <= endCX; cx++) {
            this._renderChunk(layer, cx, cy);
          }
        }
      }
    }
    _renderChunk(layer, cx, cy) {
      const key = `${layer.name},${cx},${cy}`;
      let chunk = this.chunkCache.get(key);
      if (!chunk) {
        const tm = this.scene.tilemap;
        const ts = tm.tileSize;
        const size = this.chunkSize * ts;
        chunk = document.createElement("canvas");
        chunk.width = size; chunk.height = size;
        const c = chunk.getContext("2d");
        const startTX = cx * this.chunkSize;
        const startTY = cy * this.chunkSize;
        for (let ty = 0; ty < this.chunkSize; ty++) {
          for (let tx = 0; tx < this.chunkSize; tx++) {
            const gx = startTX + tx, gy = startTY + ty;
            if (gx < 0 || gy < 0 || gx >= tm.width || gy >= tm.height) continue;
            const tileId = layer.data[gy * tm.width + gx];
            if (!tileId) continue;
            this._drawTile(c, tm.tilesets[0], tileId, tx * ts, ty * ts, ts);
          }
        }
        this.chunkCache.set(key, chunk);
      }
      this.ctx.drawImage(chunk, cx * this.chunkSize * this.scene.tilemap.tileSize, cy * this.chunkSize * this.scene.tilemap.tileSize);
    }
    _drawTile(ctx, tileset, tileId, dx, dy, ts) {
      if (!tileset || !tileset.image) return;
      const idx = tileId - tileset.firstId;
      const col = idx % tileset.cols;
      const row = Math.floor(idx / tileset.cols);
      ctx.drawImage(tileset.image, col * tileset.tileW, row * tileset.tileH, tileset.tileW, tileset.tileH, dx, dy, ts, ts);
    }
  }

  window.TilemapRenderer = TilemapRenderer;
})();