// TRANSFORMER.JS — Мобильный трансформер TransformGizmo
class TransformGizmo {
  constructor(canvas, getCamera, getSceneObjects, Callbacks = {}) {
    this.canvas = canvas;
    this.getCamera = getCamera;
    this.getSceneObjects = getSceneObjects;
    this.onSelect = Callbacks.onSelect || (() => {});
    this.onChange = Callbacks.onChange || (() => {});
    this.onHistoryCommit = Callbacks.onHistoryCommit || (() => {});
    this.isPlayMode = Callbacks.isPlayMode || (() => false);
    this.isWallDrawing = Callbacks.isWallDrawing || (() => false);
    this.onPlayTapObject = Callbacks.onPlayTapObject || (() => {});

    this.selectedObject = null;
    this.gridSize = 32;
    this.snapToGrid = true;
    this.clampPadding = 20;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.handleRadius = 12 * Math.min(dpr, 1.5);
    this.hitRadius    = 28 * Math.min(dpr, 1.5);

    this.mode = null;
    this.startScreen = { x: 0, y: 0 };
    this.startWorld  = { x: 0, y: 0 };
    this.initialObjState = null;
    this.initialCamState = null;
    this.hasModified = false;

    this.isMultiTouch = false;
    this.pinchStartDist = 0;
    this.pinchStartAngle = 0;
    this.pinchInitialObj = null;
    this.pinchInitialCam = null;

    this._activePointers = new Map();

    this.bindEvents();
  }

  worldToScreen(wx, wy) {
    const cam = this.getCamera();
    return {
      x: (wx - cam.x) * cam.zoom + this.canvas.width * .5,
      y: (wy - cam.y) * cam.zoom + this.canvas.height * .5
    };
  }

  screenToWorld(sx, sy) {
    const cam = this.getCamera();
    return {
      x: (sx - this.canvas.width * .5) / cam.zoom + cam.x,
      y: (sy - this.canvas.height * .5) / cam.zoom + cam.y
    };
  }

  clampToCanvas(sx, sy) {
    const pad = this.clampPadding;
    const maxW = Math.max(pad * 2, this.canvas.width - pad);
    const maxH = Math.max(pad * 2, this.canvas.height - pad);
    const cx = Math.max(pad, Math.min(maxW, sx));
    const cy = Math.max(pad, Math.min(maxH, sy));
    const clamped = Math.abs(cx - sx) > .5 || Math.abs(cy - sy) > .5;
    return { x: cx, y: cy, rawX: sx, rawY: sy, clamped };
  }

  getHandles(obj) {
    if (!obj) return null;
    const cam = this.getCamera();
    const hw = (obj.width || 64) * .5;
    const hh = (obj.height || 64) * .5;
    const rad = (obj.rotation || 0) * Math.PI / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);

    const transformLocal = (lx, ly) => {
      const wx = obj.x + (lx * cos - ly * sin);
      const wy = obj.y + (lx * sin + ly * cos);
      const scr = this.worldToScreen(wx, wy);
      return this.clampToCanvas(scr.x, scr.y);
    };

    const rotDistanceWorld = hh + 38 / Math.max(.25, cam.zoom);

    return {
      tl: transformLocal(-hw, -hh),
      tr: transformLocal(hw, -hh),
      br: transformLocal(hw, hh),
      bl: transformLocal(-hw, hh),
      rot: transformLocal(0, -rotDistanceWorld),
      center: this.worldToScreen(obj.x, obj.y)
    };
  }

  hitTestHandles(sx, sy) {
    if (!this.selectedObject) return null;
    const handles = this.getHandles(this.selectedObject);
    if (!handles) return null;
    const order = [
      { key: "rot", mode: "rotate" },
      { key: "tl", mode: "resize-tl" },
      { key: "tr", mode: "resize-tr" },
      { key: "br", mode: "resize-br" },
      { key: "bl", mode: "resize-bl" }
    ];
    for (const item of order) {
      const h = handles[item.key];
      const dist = Math.hypot(sx - h.x, sy - h.y);
      if (dist <= this.hitRadius) return item.mode;
    }
    return null;
  }

  isPointInObject(wx, wy, obj) {
    const dx = wx - obj.x;
    const dy = wy - obj.y;
    const rad = -((obj.rotation || 0) * Math.PI) / 180;
    const lx = dx * Math.cos(rad) - dy * Math.sin(rad);
    const ly = dx * Math.sin(rad) + dy * Math.cos(rad);
    const hw = Math.max(20, (obj.width || 64) * .5);
    const hh = Math.max(20, (obj.height || 64) * .5);
    return Math.abs(lx) <= hw && Math.abs(ly) <= hh;
  }

  pickObjectAtScreen(sx, sy) {
    const worldPt = this.screenToWorld(sx, sy);
    const objects = this.getSceneObjects();
    for (let i = objects.length - 1; i >= 0; i--) {
      const obj = objects[i];
      if (this.isPointInObject(worldPt.x, worldPt.y, obj)) return obj;
    }
    return null;
  }

  snapVal(val) {
    if (!this.snapToGrid) return Math.round(val);
    return Math.round(val / this.gridSize) * this.gridSize;
  }

  getCanvasCoords(clientX, clientY) {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: (clientX - rect.left) * (this.canvas.width / rect.width),
      y: (clientY - rect.top) * (this.canvas.height / rect.height)
    };
  }

  bindEvents() {
    if (window.PointerEvent) {
      this.canvas.addEventListener("pointerdown", (e) => this.handlePointerDown(e), { passive: false });
      this.canvas.addEventListener("pointermove", (e) => this.handlePointerMove(e), { passive: false });
      this.canvas.addEventListener("pointerup",   (e) => this.handlePointerUp(e),   { passive: false });
      this.canvas.addEventListener("pointercancel", (e) => this.handlePointerUp(e), { passive: false });
      this.canvas.addEventListener("pointerleave",  (e) => this.handlePointerUp(e), { passive: false });
    }
    this.canvas.addEventListener("mousedown",  (e) => this.handleMouseDown(e));
    window.addEventListener("mousemove", (e) => this.handleMouseMove(e));
    window.addEventListener("mouseup", () => this.handleMouseUp());
    this.canvas.addEventListener("wheel", (e) => this.handleWheel(e), { passive: false });
  }

  handlePointerDown(e) {
    if (e.pointerType === "mouse") return;

    if (this.isPlayMode()) {
      e.preventDefault();
      try { this.canvas.setPointerCapture(e.pointerId); } catch (_) {}
      const pt = this.getCanvasCoords(e.clientX, e.clientY);
      const tapped = this.pickObjectAtScreen(pt.x, pt.y);
      const worldPt = this.screenToWorld(pt.x, pt.y);
      this.onPlayTapObject(tapped, worldPt);
      return;
    }

    // Не мешаем рисованию стен
    if (this.isWallDrawing()) return;

    e.preventDefault();
    try { this.canvas.setPointerCapture(e.pointerId); } catch (_) {}

    this._activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (this._activePointers.size === 2) {
      this.isMultiTouch = true;
      this.mode = null;
      const pts = Array.from(this._activePointers.values());
      const p1 = this.getCanvasCoords(pts[0].x, pts[0].y);
      const p2 = this.getCanvasCoords(pts[1].x, pts[1].y);
      this.pinchStartDist = Math.max(10, Math.hypot(p2.x - p1.x, p2.y - p1.y));
      this.pinchStartAngle = Math.atan2(p2.y - p1.y, p2.x - p1.x) * 180 / Math.PI;
      this.pinchStartCenter = { x: (p1.x + p2.x) * .5, y: (p1.y + p2.y) * .5 };
      if (this.selectedObject) {
        this.pinchInitialObj = {
          width: this.selectedObject.width,
          height: this.selectedObject.height,
          rotation: this.selectedObject.rotation || 0,
          radius: this.selectedObject.radius || 160
        };
      } else {
        const cam = this.getCamera();
        this.pinchInitialCam = { x: cam.x, y: cam.y, zoom: cam.zoom };
      }
      return;
    }

    if (this._activePointers.size === 1) {
      this.isMultiTouch = false;
      const pt = this.getCanvasCoords(e.clientX, e.clientY);
      this.beginPointerDown(pt.x, pt.y);
    }
  }

  handlePointerMove(e) {
    if (e.pointerType === "mouse") return;
    if (this.isPlayMode()) return;
    if (this.isWallDrawing()) return;
    if (!this._activePointers.has(e.pointerId)) return;
    e.preventDefault();
    this._activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (this.isMultiTouch && this._activePointers.size === 2) {
      const pts = Array.from(this._activePointers.values());
      const p1 = this.getCanvasCoords(pts[0].x, pts[0].y);
      const p2 = this.getCanvasCoords(pts[1].x, pts[1].y);
      const currDist = Math.max(10, Math.hypot(p2.x - p1.x, p2.y - p1.y));
      const currAngle = Math.atan2(p2.y - p1.y, p2.x - p1.x) * 180 / Math.PI;
      const scaleRatio = currDist / this.pinchStartDist;
      const angleDelta = currAngle - this.pinchStartAngle;

      if (this.selectedObject && this.pinchInitialObj) {
        this.selectedObject.width  = Math.max(16, Math.round(this.pinchInitialObj.width  * scaleRatio));
        this.selectedObject.height = Math.max(16, Math.round(this.pinchInitialObj.height * scaleRatio));
        this.selectedObject.rotation = Math.round(this.pinchInitialObj.rotation + angleDelta);
        if (this.selectedObject.type === "light") {
          this.selectedObject.radius = Math.max(24, Math.round(this.pinchInitialObj.radius * scaleRatio));
        }
        this.hasModified = true;
        this.onChange(this.selectedObject);
      } else if (this.pinchInitialCam) {
        const cam = this.getCamera();
        cam.zoom = Math.max(.25, Math.min(3, this.pinchInitialCam.zoom * scaleRatio));
        const currCenter = { x: (p1.x + p2.x) * .5, y: (p1.y + p2.y) * .5 };
        cam.x = this.pinchInitialCam.x - (currCenter.x - this.pinchStartCenter.x) / cam.zoom;
        cam.y = this.pinchInitialCam.y - (currCenter.y - this.pinchStartCenter.y) / cam.zoom;
        this.onChange(null);
      }
      return;
    }

    if (this._activePointers.size === 1) {
      const pt = this.getCanvasCoords(e.clientX, e.clientY);
      this.updatePointerMove(pt.x, pt.y);
    }
  }

  handlePointerUp(e) {
    if (e.pointerType === "mouse") return;
    this._activePointers.delete(e.pointerId);
    if (this.isPlayMode()) return;
    if (this.isWallDrawing()) return;

    if (this._activePointers.size === 0) {
      if (this.hasModified) {
        this.onHistoryCommit();
        this.hasModified = false;
      }
      this.isMultiTouch = false;
      this.mode = null;
    }
  }

  handleMouseDown(e) {
    if (e.button !== 0) return;
    if (this.isPlayMode()) {
      const pt = this.getCanvasCoords(e.clientX, e.clientY);
      const tapped = this.pickObjectAtScreen(pt.x, pt.y);
      const worldPt = this.screenToWorld(pt.x, pt.y);
      this.onPlayTapObject(tapped, worldPt);
      return;
    }
    if (this.isWallDrawing()) return;
    const pt = this.getCanvasCoords(e.clientX, e.clientY);
    this.beginPointerDown(pt.x, pt.y);
  }

  handleMouseMove(e) {
    if (this.isPlayMode() || this.isWallDrawing() || !this.mode) return;
    const pt = this.getCanvasCoords(e.clientX, e.clientY);
    this.updatePointerMove(pt.x, pt.y);
  }

  handleMouseUp() {
    if (this.hasModified) {
      this.onHistoryCommit();
      this.hasModified = false;
    }
    this.mode = null;
  }

  handleWheel(e) {
    if (this.isPlayMode()) return;
    e.preventDefault();
    const cam = this.getCamera();
    const factor = e.deltaY < 0 ? 1.1 : .9;
    cam.zoom = Math.max(.25, Math.min(3, Number((cam.zoom * factor).toFixed(2))));
    this.onChange(this.selectedObject);
  }

  beginPointerDown(sx, sy) {
    this.startScreen = { x: sx, y: sy };
    this.startWorld = this.screenToWorld(sx, sy);
    this.hasModified = false;

    const handleHit = this.hitTestHandles(sx, sy);
    if (handleHit && this.selectedObject) {
      this.mode = handleHit;
      this.initialObjState = {
        x: this.selectedObject.x, y: this.selectedObject.y,
        width: this.selectedObject.width, height: this.selectedObject.height,
        rotation: this.selectedObject.rotation || 0,
        radius: this.selectedObject.radius || 160
      };
      return;
    }

    const picked = this.pickObjectAtScreen(sx, sy);
    if (picked) {
      this.selectedObject = picked;
      this.onSelect(picked);
      this.mode = "move";
      this.initialObjState = {
        x: picked.x, y: picked.y,
        width: picked.width, height: picked.height,
        rotation: picked.rotation || 0,
        radius: picked.radius || 160
      };
    } else {
      this.selectedObject = null;
      this.onSelect(null);
      this.mode = "pan-camera";
      const cam = this.getCamera();
      this.initialCamState = { x: cam.x, y: cam.y };
    }
  }

  updatePointerMove(sx, sy) {
    if (!this.mode) return;
    const cam = this.getCamera();
    const currWorld = this.screenToWorld(sx, sy);

    if (this.mode === "pan-camera" && this.initialCamState) {
      const dx = (sx - this.startScreen.x) / cam.zoom;
      const dy = (sy - this.startScreen.y) / cam.zoom;
      cam.x = Math.round(this.initialCamState.x - dx);
      cam.y = Math.round(this.initialCamState.y - dy);
      this.onChange(null);
      return;
    }

    const obj = this.selectedObject;
    if (!obj || !this.initialObjState) return;

    if (this.mode === "move") {
      const wdx = currWorld.x - this.startWorld.x;
      const wdy = currWorld.y - this.startWorld.y;
      obj.x = this.snapVal(this.initialObjState.x + wdx);
      obj.y = this.snapVal(this.initialObjState.y + wdy);
      this.hasModified = true;
      this.onChange(obj);
      return;
    }

    if (this.mode === "rotate") {
      const centerScr = this.worldToScreen(obj.x, obj.y);
      const angle = Math.atan2(sy - centerScr.y, sx - centerScr.x) * 180 / Math.PI + 90;
      let deg = Math.round(angle);
      if (deg < 0) deg += 360;
      obj.rotation = deg % 360;
      this.hasModified = true;
      this.onChange(obj);
      return;
    }

    if (this.mode.startsWith("resize-")) {
      const rad = -((obj.rotation || 0) * Math.PI) / 180;
      const dx = currWorld.x - obj.x;
      const dy = currWorld.y - obj.y;
      const localX = Math.abs(dx * Math.cos(rad) - dy * Math.sin(rad));
      const localY = Math.abs(dx * Math.sin(rad) + dy * Math.cos(rad));
      let newW = Math.max(16, Math.round(localX * 2));
      let newH = Math.max(16, Math.round(localY * 2));
      if (this.snapToGrid) {
        newW = Math.max(this.gridSize, Math.round(newW / (this.gridSize * .5)) * (this.gridSize * .5));
        newH = Math.max(this.gridSize, Math.round(newH / (this.gridSize * .5)) * (this.gridSize * .5));
      }
      obj.width = newW;
      obj.height = newH;
      if (obj.type === "light") {
        obj.radius = Math.max(24, Math.round(Math.max(newW, newH) * 1.5));
      }
      this.hasModified = true;
      this.onChange(obj);
    }
  }

  draw(ctx) {
    if (this.isPlayMode() || this.isWallDrawing() || !this.selectedObject) return;
    const obj = this.selectedObject;
    const handles = this.getHandles(obj);
    if (!handles) return;

    ctx.save();
    ctx.strokeStyle = "#00F59B";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(handles.tl.rawX, handles.tl.rawY);
    ctx.lineTo(handles.tr.rawX, handles.tr.rawY);
    ctx.lineTo(handles.br.rawX, handles.br.rawY);
    ctx.lineTo(handles.bl.rawX, handles.bl.rawY);
    ctx.closePath();
    ctx.stroke();

    const topMidX = (handles.tl.rawX + handles.tr.rawX) * .5;
    const topMidY = (handles.tl.rawY + handles.tr.rawY) * .5;
    ctx.beginPath();
    ctx.strokeStyle = "#00D2FF";
    ctx.moveTo(topMidX, topMidY);
    ctx.lineTo(handles.rot.x, handles.rot.y);
    ctx.stroke();

    const corners = ["tl", "tr", "br", "bl"];
    for (const key of corners) {
      const h = handles[key];
      if (h.clamped) {
        ctx.save();
        ctx.setLineDash([5, 4]);
        ctx.strokeStyle = "rgba(0, 245, 155, 0.75)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(h.rawX, h.rawY);
        ctx.lineTo(h.x, h.y);
        ctx.stroke();
        ctx.restore();
      }
    }

    for (const key of corners) {
      const h = handles[key];
      ctx.beginPath();
      ctx.fillStyle = h.clamped ? "#00D2FF" : "#060913";
      ctx.strokeStyle = "#00F59B";
      ctx.lineWidth = 2.5;
      ctx.arc(h.x, h.y, this.handleRadius, 0, Math.PI * 2);
      ctx.fill(); ctx.stroke();
      ctx.beginPath();
      ctx.fillStyle = "#00F59B";
      ctx.arc(h.x, h.y, 4, 0, Math.PI * 2);
      ctx.fill();
    }

    const rotH = handles.rot;
    ctx.beginPath();
    ctx.fillStyle = "#00D2FF";
    ctx.strokeStyle = "#060913";
    ctx.lineWidth = 2.5;
    ctx.arc(rotH.x, rotH.y, this.handleRadius + 1, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();

    const labelPos = this.clampToCanvas(
      handles.center.x,
      handles.center.y + obj.height * .5 * this.getCamera().zoom + 26
    );
    const infoText = `${Math.round(obj.width)}×${Math.round(obj.height)} · ${Math.round(obj.rotation || 0)}°`;
    ctx.font = "600 11px \"JetBrains Mono\", monospace";
    const textW = ctx.measureText(infoText).width + 14;
    ctx.fillStyle = "rgba(6, 9, 19, 0.88)";
    ctx.fillRect(labelPos.x - textW * .5, labelPos.y - 11, textW, 22);
    ctx.strokeStyle = "rgba(0, 245, 155, 0.45)";
    ctx.lineWidth = 1;
    ctx.strokeRect(labelPos.x - textW * .5, labelPos.y - 11, textW, 22);
    ctx.fillStyle = "#00F59B";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(infoText, labelPos.x, labelPos.y);
    ctx.restore();
  }
}

window.TransformGizmo = TransformGizmo;