const { Schema, MapSchema, defineTypes } = require("@colyseus/schema");

class Player extends Schema {
  constructor() {
    super();
    this.name = "Игрок";
    this.x = 300;
    this.y = 300;
    this.color = "#00F59B";
    this.alive = true;
    this.hidden = false;
    this.role = "player";
    this.customJson = "{}";
  }
}
defineTypes(Player, {
  name: "string",
  x: "number",
  y: "number",
  color: "string",
  alive: "boolean",
  hidden: "boolean",
  role: "string",
  customJson: "string"
});

class GameState extends Schema {
  constructor() {
    super();
    this.players = new MapSchema();
    this.phase = "lobby";
    this.hostId = "";
    this.winner = "";
    this.customJson = "{}";
  }
}
defineTypes(GameState, {
  players: { map: Player },
  phase: "string",
  hostId: "string",
  winner: "string",
  customJson: "string"
});

module.exports = { Player, GameState };