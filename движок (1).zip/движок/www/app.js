// APP.JS — Ядро 2D No-Code/Low-Code игрового движка TapEng1ne
(function () {
  "use strict";

  const LEVEL_WIDTH  = 1920;
  const LEVEL_HEIGHT = 1080;

  const COLORS = {
    block:    "#64748B",
    platform: "#334155",
    trigger:  "#FBBF24",
    light:    "#FBBF24",
    spawn:    "#FF6B6B",
    wall:     "#334155",
    default:  "#94A3B8"
  };

  const DEFAULT_LIGHT_RGBA = "rgba(255, 240, 210, 0.9)";

  const DEFAULT_GAME_JS = `// GAME.JS — логика твоей игры (выполняется в runtime.js)
game.on("start", function () {
  ui.notify("Матч начался! Роль: " + game.me.role, "ok");
});
game.on("interact", function (me, obj) {
  if (obj.type === "hiding") {
    if (me.hidden) { game.unhide(); ui.notify("Вышел", "warn"); }
    else { game.hide(); ui.notify("Спрятался", "ok"); tg.haptic(); }
  }
});
game.on("end", function (result) {
  ui.overlay("end", '<h1 style="color:#00F59B;font-size:40px;">Игра окончена</h1>' +
    '<button onclick="location.reload()" style="padding:14px 28px;border-radius:12px;' +
    'border:2px solid #00F59B;background:transparent;color:#00F59B;font-size:16px;font-weight:700;">Ещё раз</button>');
});
`;

  const EngineState = {
    playMode: false,
    wallMode: false,
    wallDrawing: { active: false, startWorld: null, currentWorld: null },
    showGrid: true,
    snapToGrid: true,
    gridSize: 32,
    levelWidth: LEVEL_WIDTH,
    levelHeight: LEVEL_HEIGHT,
    bgColor: "#060913",
    activeSceneIndex: 0,
    scenes: [{
      id: "scene_1",
      name: "Сцена 1 (Главная)",
      bgColor: "#060913",
      ambientDarkness: 0,
      objects: []
    }],
    variables: [
      { name: "score", type: "number", value: 0 },
      { name: "hp",    type: "number", value: 100 }
    ],
    showHudVars: true,
    logicRules: [],
    assets: [],
    audios: [],
    playerSprites: { idle: null, walk: null, hide: null },
    spineFiles: {
      pngName: null, pngDataUrl: null,
      atlasName: null, atlasText: null,
      jsonName: null, jsonText: null
    },
    codeLanguage: "javascript",
    runCodeOnUpdate: false,
    jsCode: `const hero = engine.getObjectByName("Hero") || engine.objects[0];
if (hero) hero.rotation = (hero.rotation + 5) % 360;`,
    pyCode: `# Python (Pyodide)
if len(objects) > 0:
    objects[0]["y"] -= 16
    vars["score"] = vars.get("score", 0) + 10`,
    gameJsCode: DEFAULT_GAME_JS,
    exportTarget: "web",
    history: [],
    historyIndex: -1,
    savedBeforePlay: null,
    netState: null,
    myNetId: null,
    _lastNetSend: 0,
    serverUrl: localStorage.getItem("tapeng1ne_server_url") || "",
    playerName: localStorage.getItem("tapeng1ne_player_name") || "Игрок",
    playerColor: localStorage.getItem("tapeng1ne_player_color") || "#00F59B",
    multiplayerExport: localStorage.getItem("tapeng1ne_mp_export") === "1",
    mpButtonEnabled: localStorage.getItem("tapeng1ne_mp_btn_enabled") !== "0",
    mpButtonText: localStorage.getItem("tapeng1ne_mp_btn_text") || "Играть онлайн",
    mpButtonMode: localStorage.getItem("tapeng1ne_mp_btn_mode") || "both"
  };

  window.EngineState = EngineState;

  Object.defineProperty(EngineState, "ambientDarkness", {
    get() { return this.scenes[this.activeSceneIndex]?.ambientDarkness ?? 0; },
    set(v) {
      const sc = this.scenes[this.activeSceneIndex];
      if (sc) sc.ambientDarkness = Number(v) || 0;
    }
  });

  const Camera = {
    x: 0, y: 0, zoom: 1,
    targetId: null,
    smoothing: .08,
    update(objects) {
      if (!this.targetId) return;
      const target = objects.find((o) => o.id === this.targetId || o.cameraFollow);
      if (target) {
        this.x += (target.x - this.x) * this.smoothing;
        this.y += (target.y - this.y) * this.smoothing;
      }
    }
  };

  const canvas = document.getElementById("game-canvas");
  const ctx = canvas.getContext("2d");

  if (!CanvasRenderingContext2D.prototype.roundRect) {
    CanvasRenderingContext2D.prototype.roundRect = function(x, y, w, h, r) {
      const rr = Math.min(typeof r === "number" ? r : 6, w * 0.5, h * 0.5);
      this.beginPath();
      this.moveTo(x + rr, y);
      this.arcTo(x + w, y,     x + w, y + h, rr);
      this.arcTo(x + w, y + h, x,     y + h, rr);
      this.arcTo(x,     y + h, x,     y,     rr);
      this.arcTo(x,     y,     x + w, y,     rr);
      this.closePath();
      return this;
    };
  }

  const lightCanvas = document.createElement("canvas");
  const lightCtx = lightCanvas.getContext("2d");

  let gizmo = null;
  let pyodideInstance = null;
  let pyodideLoading = false;
  let lastTime = performance.now();
  let tickAccumulator = 0;
  const activeKeys = {};
  let tilemapRenderer = null;

  function getCurrentScene() {
    return EngineState.scenes[EngineState.activeSceneIndex] || EngineState.scenes[0];
  }
  function getSceneObjects() {
    return getCurrentScene().objects;
  }

  function resizeCanvas() {
    const workspace = document.getElementById("workspace");
    const w = workspace ? workspace.clientWidth : window.innerWidth;
    const h = workspace ? workspace.clientHeight : window.innerHeight;
    canvas.width = Math.max(300, w);
    canvas.height = Math.max(240, h);
    lightCanvas.width = canvas.width;
    lightCanvas.height = canvas.height;
  }
  window.addEventListener("resize", resizeCanvas);

  function pushHistory() {
    if (EngineState.playMode) return;
    const snapshot = JSON.stringify({
      scenes: EngineState.scenes,
      activeSceneIndex: EngineState.activeSceneIndex,
      bgColor: EngineState.bgColor,
      variables: EngineState.variables,
      logicRules: EngineState.logicRules
    });
    if (EngineState.historyIndex >= 0 && EngineState.history[EngineState.historyIndex] === snapshot) return;
    EngineState.history = EngineState.history.slice(0, EngineState.historyIndex + 1);
    EngineState.history.push(snapshot);
    if (EngineState.history.length > 40) EngineState.history.shift();
    EngineState.historyIndex = EngineState.history.length - 1;
  }

  function restoreSnapshot(snapshotStr) {
    try {
      const data = JSON.parse(snapshotStr);
      EngineState.scenes = data.scenes;
      EngineState.activeSceneIndex = data.activeSceneIndex || 0;
      EngineState.bgColor = data.bgColor || "#060913";
      EngineState.variables = data.variables || [];
      EngineState.logicRules = data.logicRules || [];
      for (const sc of EngineState.scenes) {
        for (const o of sc.objects) {
          if (o.imageSrc && !o.imageElement) {
            const img = new Image();
            img.src = o.imageSrc;
            o.imageElement = img;
          }
        }
      }
      if (gizmo) gizmo.selectedObject = null;
      syncAllUI();
    } catch (err) {
      consoleLog("Ошибка восстановления: " + err.message);
    }
  }

  function undoAction() {
    if (EngineState.historyIndex > 0) {
      EngineState.historyIndex--;
      restoreSnapshot(EngineState.history[EngineState.historyIndex]);
    }
  }
  function redoAction() {
    if (EngineState.historyIndex < EngineState.history.length - 1) {
      EngineState.historyIndex++;
      restoreSnapshot(EngineState.history[EngineState.historyIndex]);
    }
  }

  let objectCounter = 1;

  function _makeBaseObject(id, presetType) {
    return {
      id, name: "Объект", type: presetType, shape: "rect",
      x: Math.round(Camera.x / 32) * 32,
      y: Math.round(Camera.y / 32) * 32,
      width: 96, height: 96,
      rotation: 0, color: COLORS.block, alpha: 1,
      cameraFollow: false, gravity: false, solid: true,
      controllable: false, emitsLight: false,
      vx: 0, vy: 0, radius: 220, intensity: .9, softness: .5,
      rgba: DEFAULT_LIGHT_RGBA, imageSrc: null,
      z: 0, parallaxFactor: 1,
      spritesheet: null, currentFrame: 0, animTime: 0,
      collider: "aabb", colliderRadius: 32,
      isNetworked: false, netId: null
    };
  }

  function createSceneObject(presetType) {
    const objs = getSceneObjects();
    const id = "obj_" + Date.now() + "_" + objectCounter++;
    const offset = (objs.length % 5 - 2) * 32;
    const base = _makeBaseObject(id, presetType);
    base.x += offset;

    if (presetType === "light") {
      base.name = "Свет " + (objs.filter((o) => o.emitsLight).length + 1);
      base.width = 48; base.height = 48;
      base.color = COLORS.light; base.shape = "circle";
      base.solid = false; base.radius = 220;
      base.intensity = .92; base.softness = .5;
      base.rgba = DEFAULT_LIGHT_RGBA; base.emitsLight = true;
      if (getCurrentScene().ambientDarkness === 0) getCurrentScene().ambientDarkness = .65;
    } else if (presetType === "spawnPoint") {
      base.name = "Спавн";
      base.type = "spawnPoint";
      base.width = 32; base.height = 32;
      base.color = COLORS.spawn; base.shape = "circle";
      base.solid = false;
    } else if (presetType === "wall") {
      base.name = "Стена";
      base.type = "wall";
      base.width = 32; base.height = 32;
      base.color = COLORS.wall; base.shape = "rect";
      base.solid = true;
    } else if (presetType === "circle") {
      base.name = "Круг " + (objs.length + 1);
      base.width = 96; base.height = 96;
      base.color = COLORS.block; base.shape = "circle";
      base.collider = "circle"; base.colliderRadius = 48;
    } else if (presetType === "triangle") {
      base.name = "Треугольник " + (objs.length + 1);
      base.width = 96; base.height = 96;
      base.color = COLORS.block; base.shape = "triangle";
    } else if (presetType === "line") {
      base.name = "Линия " + (objs.length + 1);
      base.width = 256; base.height = 6;
      base.color = COLORS.block; base.shape = "line"; base.solid = false;
    } else if (presetType === "platform") {
      base.name = "Платформа";
      base.width = 256; base.height = 32;
      base.y = Math.round(Camera.y / 32) * 32 + 128;
      base.color = COLORS.platform; base.shape = "platform"; base.solid = true;
    } else if (presetType === "coin" || presetType === "trigger") {
      base.name = "Триггер"; base.type = "trigger";
      base.width = 48; base.height = 48;
      base.color = COLORS.trigger; base.shape = "trigger"; base.solid = false;
    } else {
      base.name = "Блок " + (objs.length + 1);
      base.type = "block"; base.color = COLORS.block; base.shape = "rect";
    }

    objs.push(base);
    if (gizmo) gizmo.selectedObject = base;
    pushHistory();
    syncAllUI();
    return base;
  }
  window.createSceneObject = createSceneObject;

  function createSpriteFromFile(file) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result;
        const img = new Image();
        img.onload = () => {
          const objs = getSceneObjects();
          const id = "obj_" + Date.now() + "_" + objectCounter++;
          const base = _makeBaseObject(id, "sprite");
          base.name = (file.name || "Спрайт").replace(/\.[^.]+$/, "");
          base.width  = img.naturalWidth  || 128;
          base.height = img.naturalHeight || 128;
          base.solid = false;
          base.imageSrc = dataUrl;
          base.imageElement = img;
          objs.push(base);
          if (gizmo) gizmo.selectedObject = base;
          pushHistory();
          syncAllUI();
          resolve(base);
        };
        img.onerror = () => { consoleLog("Не удалось: " + file.name); resolve(null); };
        img.src = dataUrl;
      };
      reader.readAsDataURL(file);
    });
  }
  window.createSpriteFromFile = createSpriteFromFile;

  function _finishWallDrawing() {
    const start = EngineState.wallDrawing.startWorld;
    const cur = EngineState.wallDrawing.currentWorld;
    if (!start || !cur) {
      EngineState.wallDrawing.active = false;
      EngineState.wallDrawing.startWorld = null;
      EngineState.wallDrawing.currentWorld = null;
      return;
    }

    let w = Math.abs(cur.x - start.x);
    let h = Math.abs(cur.y - start.y);
    let cx = (start.x + cur.x) / 2;
    let cy = (start.y + cur.y) / 2;

    if (w < 8 && h < 8) {
      w = EngineState.gridSize;
      h = EngineState.gridSize;
      cx = start.x; cy = start.y;
    } else {
      w = Math.max(16, w);
      h = Math.max(16, h);
    }

    if (EngineState.snapToGrid) {
      const g = EngineState.gridSize;
      cx = Math.round(cx / g) * g;
      cy = Math.round(cy / g) * g;
      w = Math.max(g, Math.round(w / g) * g);
      h = Math.max(g, Math.round(h / g) * g);
    }

    const objs = getSceneObjects();
    const id = "obj_" + Date.now() + "_" + objectCounter++;
    const base = _makeBaseObject(id, "wall");
    base.name = "Стена";
    base.type = "wall";
    base.shape = "rect";
    base.color = COLORS.wall;
    base.solid = true;
    base.x = cx; base.y = cy;
    base.width = w; base.height = h;
    objs.push(base);

    EngineState.wallDrawing.active = false;
    EngineState.wallDrawing.startWorld = null;
    EngineState.wallDrawing.currentWorld = null;
    pushHistory();
    syncAllUI();
  }

  function drawGrid() {
    if (!EngineState.showGrid || EngineState.playMode) return;
    const step = EngineState.gridSize;
    const halfW = canvas.width * .5 / Camera.zoom;
    const halfH = canvas.height * .5 / Camera.zoom;
    const startX = Math.floor((Camera.x - halfW) / step) * step;
    const endX = Math.ceil((Camera.x + halfW) / step) * step;
    const startY = Math.floor((Camera.y - halfH) / step) * step;
    const endY = Math.ceil((Camera.y + halfH) / step) * step;

    ctx.save();
    ctx.lineWidth = 1 / Camera.zoom;
    ctx.strokeStyle = "rgba(120, 180, 255, 0.18)";
    ctx.beginPath();
    for (let x = startX; x <= endX; x += step) { ctx.moveTo(x, startY); ctx.lineTo(x, endY); }
    for (let y = startY; y <= endY; y += step) { ctx.moveTo(startX, y); ctx.lineTo(endX, y); }
    ctx.stroke();

    ctx.strokeStyle = "rgba(120, 180, 255, 0.35)";
    ctx.beginPath();
    ctx.moveTo(startX, 0); ctx.lineTo(endX, 0);
    ctx.moveTo(0, startY); ctx.lineTo(0, endY);
    ctx.stroke();
    ctx.restore();
  }

  function drawLevelBounds() {
    if (EngineState.playMode) return;
    ctx.save();
    ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";
    ctx.lineWidth = 2 / Camera.zoom;
    ctx.setLineDash([10 / Camera.zoom, 6 / Camera.zoom]);
    ctx.strokeRect(0, 0, LEVEL_WIDTH, LEVEL_HEIGHT);
    ctx.setLineDash([]);
    ctx.restore();
  }

  function drawSceneObject(obj) {
    ctx.save();
    const pFactor = obj.parallaxFactor ?? 1;
    const offsetX = Camera.x * (1 - pFactor);
    const offsetY = Camera.y * (1 - pFactor);
    ctx.translate(obj.x - offsetX, obj.y - offsetY);
    ctx.rotate((obj.rotation || 0) * Math.PI / 180);
    ctx.globalAlpha = obj.alpha ?? 1;

    const hw = obj.width * .5;
    const hh = obj.height * .5;

    if (obj.type === "spawnPoint") {
      ctx.strokeStyle = "#FF6B6B";
      ctx.lineWidth = 2 / Camera.zoom;
      ctx.beginPath();
      ctx.arc(0, 0, Math.min(hw, hh), 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-hw * 0.7, -hh * 0.7); ctx.lineTo(hw * 0.7, hh * 0.7);
      ctx.moveTo(hw * 0.7, -hh * 0.7); ctx.lineTo(-hw * 0.7, hh * 0.7);
      ctx.stroke();
      ctx.restore();
      return;
    }

    if (obj.spritesheet && obj.imageElement && obj.imageElement.complete) {
      const ss = obj.spritesheet;
      const frame = obj.currentFrame ?? 0;
      const col = frame % ss.frames;
      const row = Math.floor(frame / ss.frames);
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(obj.imageElement, col * ss.frameW, row * ss.frameH, ss.frameW, ss.frameH, -hw, -hh, obj.width, obj.height);
      ctx.restore();
      return;
    }

    if (obj.imageElement && obj.imageElement.complete) {
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(obj.imageElement, -hw, -hh, obj.width, obj.height);
      ctx.restore();
      return;
    }

    if (!EngineState.playMode && obj.emitsLight) {
      ctx.save();
      ctx.globalAlpha = (obj.alpha ?? 1) * 0.25;
      ctx.fillStyle = obj.rgba || DEFAULT_LIGHT_RGBA;
      ctx.beginPath();
      ctx.arc(0, 0, Math.min(hw, hh) * 0.85, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "rgba(255, 220, 150, 0.35)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, 0, obj.radius || 180, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    const shape = obj.shape || (obj.type === "trigger" || obj.type === "coin" ? "trigger" : "rect");

    if (shape === "trigger") {
      ctx.fillStyle = obj.color || COLORS.trigger;
      ctx.strokeStyle = "rgba(0, 0, 0, 0.18)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, 0, Math.min(hw, hh), 0, Math.PI * 2);
      ctx.fill(); ctx.stroke();
      ctx.restore();
      return;
    }

    if (shape === "circle") {
      ctx.fillStyle = obj.color || COLORS.block;
      ctx.strokeStyle = "rgba(255, 255, 255, 0.14)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, 0, Math.min(hw, hh), 0, Math.PI * 2);
      ctx.fill(); ctx.stroke();
      ctx.restore();
      return;
    }

    if (shape === "triangle") {
      ctx.fillStyle = obj.color || COLORS.block;
      ctx.strokeStyle = "rgba(255, 255, 255, 0.14)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, -hh); ctx.lineTo(hw, hh); ctx.lineTo(-hw, hh);
      ctx.closePath();
      ctx.fill(); ctx.stroke();
      ctx.restore();
      return;
    }

    if (shape === "line") {
      ctx.strokeStyle = obj.color || COLORS.block;
      ctx.lineWidth = Math.max(2, obj.height);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(-hw, 0); ctx.lineTo(hw, 0);
      ctx.stroke();
      ctx.restore();
      return;
    }

    if (shape === "platform") {
      ctx.fillStyle = obj.color || COLORS.platform;
      ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(-hw, -hh, obj.width, obj.height, 3);
      ctx.fill(); ctx.stroke();
      ctx.restore();
      return;
    }

    ctx.fillStyle = obj.color || COLORS.block;
    ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(-hw, -hh, obj.width, obj.height, 4);
    ctx.fill(); ctx.stroke();
    ctx.restore();
  }

  function render2DLighting(objects) {
    const darkness = Number(getCurrentScene().ambientDarkness) || 0;
    const lights = objects.filter(o => o.emitsLight && (o.intensity ?? 0.9) > 0.005);
    if (darkness <= 0.005 && lights.length === 0) return;
    if (!window.ShadowRenderer || !window.ShadowRenderer.isReady()) {
      if (window.ShadowRenderer) window.ShadowRenderer.init?.();
    }
    if (!window.ShadowRenderer || !window.ShadowRenderer.isReady()) {
      _render2DLightingFallback(darkness, lights);
      return;
    }
    const occluders = objects
      .filter(o => o.solid && !o.emitsLight && o.type !== "trigger")
      .map(o => ({ x: o.x, y: o.y, w: o.width, h: o.height, rotation: (o.rotation || 0) * Math.PI / 180 }));
    window.ShadowRenderer.render({
      darkness,
      lights: lights.map(l => ({
        x: l.x, y: l.y,
        radius: l.radius || 220,
        intensity: l.intensity ?? 0.9,
        rgba: l.rgba || DEFAULT_LIGHT_RGBA,
        softness: l.softness ?? 0.5
      })),
      occluders,
      camera: Camera,
      canvasWidth: canvas.width,
      canvasHeight: canvas.height,
      targetCtx: ctx
    });
  }

  function _render2DLightingFallback(darkness, lights) {
    const w = canvas.width, h = canvas.height;
    lightCtx.clearRect(0, 0, w, h);
    if (darkness > 0.005) {
      lightCtx.globalCompositeOperation = "source-over";
      lightCtx.fillStyle = `rgba(2,4,10,${Math.min(1, Math.max(0, darkness))})`;
      lightCtx.fillRect(0, 0, w, h);
      lightCtx.globalCompositeOperation = "destination-out";
      for (const light of lights) {
        const sx = (light.x - Camera.x) * Camera.zoom + w * 0.5;
        const sy = (light.y - Camera.y) * Camera.zoom + h * 0.5;
        const sr = Math.max(10, (light.radius || 180) * Camera.zoom);
        const a = Math.min(1, Math.max(0, Number(light.intensity ?? 0.9)));
        const g = lightCtx.createRadialGradient(sx, sy, 0, sx, sy, sr);
        g.addColorStop(0, `rgba(0,0,0,${a})`);
        g.addColorStop(0.55, `rgba(0,0,0,${a * 0.65})`);
        g.addColorStop(1, "rgba(0,0,0,0)");
        lightCtx.fillStyle = g;
        lightCtx.beginPath(); lightCtx.arc(sx, sy, sr, 0, Math.PI * 2); lightCtx.fill();
      }
    }
    lightCtx.globalCompositeOperation = "source-over";
    ctx.drawImage(lightCanvas, 0, 0);
  }

  function executeLogicRules(eventType, triggerObj, ctxArg = {}) {
    if (window.LogicChains && typeof window.LogicChains.dispatch === "function") {
      window.LogicChains.dispatch({
        event: eventType, trigger: triggerObj, context: ctxArg,
        state: EngineState, camera: Camera, getSceneObjects
      });
    }
  }

  function updatePlaySimulation(dt) {
    const objects = getSceneObjects();
    tickAccumulator += dt;
    if (tickAccumulator >= 1) {
      tickAccumulator = 0;
      executeLogicRules("onTick", null);
    }

    for (let i = 0; i < objects.length; i++) {
      const obj = objects[i];
      if (obj.controllable) {
        const moveSpeed = 240;
        if (activeKeys["ArrowLeft"] || activeKeys["KeyA"]) obj.x -= moveSpeed * dt;
        else if (activeKeys["ArrowRight"] || activeKeys["KeyD"]) obj.x += moveSpeed * dt;
        if ((activeKeys["ArrowUp"] || activeKeys["KeyW"] || activeKeys["Space"]) && Math.abs(obj.vy || 0) < 5) obj.vy = -440;
      }

      if (obj.gravity) {
        obj.vy = (obj.vy || 0) + 920 * dt;
        obj.y += obj.vy * dt;
        if (!obj._collidingIds) obj._collidingIds = new Set();
        const nowColliding = new Set();

        for (let j = 0; j < objects.length; j++) {
          if (i === j) continue;
          const other = objects[j];
          if (!other.solid) continue;
          const halfW = (obj.width + other.width) * 0.5;
          const halfH = (obj.height + other.height) * 0.5;
          const dx = obj.x - other.x, dy = obj.y - other.y;
          if (Math.abs(dx) < halfW && Math.abs(dy) < halfH) {
            nowColliding.add(other.id);
            if (!obj._collidingIds.has(other.id)) executeLogicRules("onCollide", obj, { other });
            const overlapY = halfH - Math.abs(dy);
            if (overlapY < halfW - Math.abs(dx)) {
              if (dy < 0) { obj.y = other.y - halfH; if (obj.vy > 0) obj.vy = 0; }
              else { obj.y = other.y + halfH; if (obj.vy < 0) obj.vy = 0; }
            } else {
              if (dx < 0) obj.x = other.x - halfW;
              else obj.x = other.x + halfW;
              obj.vx = 0;
            }
          }
        }
        obj._collidingIds = nowColliding;
      }
    }

    for (const obj of objects) {
      if (obj.spritesheet && obj.spritesheet.frames > 1) {
        obj.animTime = (obj.animTime || 0) + dt;
        const frameDur = 1 / (obj.spritesheet.fps || 8);
        if (obj.animTime >= frameDur) {
          obj.animTime -= frameDur;
          obj.currentFrame = ((obj.currentFrame || 0) + 1) % obj.spritesheet.frames;
        }
      }
    }

    if (EngineState.netState?.players) {
      const playersMap = EngineState.netState.players;
      const entries = playersMap.forEach
        ? (() => { const a = []; playersMap.forEach((v, k) => a.push([k, v])); return a; })()
        : Object.entries(playersMap);
      for (const [id, netPlayer] of entries) {
        if (id === EngineState.myNetId) continue;
        let obj = objects.find(o => o.netId === id);
        if (!obj) {
          obj = createSceneObject("circle");
          obj.netId = id;
          obj.name = netPlayer.name || "Игрок";
          obj.isNetworked = true;
          obj.collider = "circle";
          obj.colliderRadius = 16;
          obj.width = 32; obj.height = 32;
        }
        obj.x += (netPlayer.x - obj.x) * 0.3;
        obj.y += (netPlayer.y - obj.y) * 0.3;
        obj.alpha = netPlayer.alive === false ? 0.3 : 1;
      }
    }

    if (EngineState.myNetId && EngineState.playMode && window.TapNet) {
      if (!EngineState._lastNetSend || Date.now() - EngineState._lastNetSend > 100) {
        EngineState._lastNetSend = Date.now();
        const me = objects.find(o => o.netId === EngineState.myNetId);
        if (me) window.TapNet.send("move", { x: me.x, y: me.y });
      }
    }

    if (EngineState.runCodeOnUpdate && EngineState.codeLanguage !== "game") runUserCode(true);
    Camera.update(objects);
  }

  function mainLoop(now) {
    const dt = Math.min(.05, (now - lastTime) / 1e3);
    lastTime = now;

    const scene = getCurrentScene();
    const objects = scene.objects;

    if (EngineState.playMode) {
      updatePlaySimulation(dt);
      const halfW = canvas.width / (2 * Camera.zoom);
      const halfH = canvas.height / (2 * Camera.zoom);
      const minX = halfW, maxX = LEVEL_WIDTH - halfW;
      const minY = halfH, maxY = LEVEL_HEIGHT - halfH;
      if (maxX < minX) Camera.x = LEVEL_WIDTH * 0.5;
      else Camera.x = Math.max(minX, Math.min(maxX, Camera.x));
      if (maxY < minY) Camera.y = LEVEL_HEIGHT * 0.5;
      else Camera.y = Math.max(minY, Math.min(maxY, Camera.y));
    } else {
      const followTarget = objects.find((o) => o.cameraFollow);
      if (followTarget && gizmo && gizmo.mode !== "pan-camera") Camera.targetId = followTarget.id;
    }

    ctx.fillStyle = EngineState.bgColor || "#060913";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.save();
    ctx.translate(canvas.width * .5, canvas.height * .5);
    ctx.scale(Camera.zoom, Camera.zoom);
    ctx.translate(-Camera.x, -Camera.y);

    if (scene.tilemap && !EngineState.playMode) {
      if (!tilemapRenderer || tilemapRenderer.scene !== scene) {
        tilemapRenderer = new window.TilemapRenderer(scene, ctx);
      }
      tilemapRenderer.render(Camera, canvas.width, canvas.height);
    }

    const sortedObjects = [...objects].sort((a, b) => (a.z ?? 0) - (b.z ?? 0));
    for (const obj of sortedObjects) drawSceneObject(obj);

    if (EngineState.wallMode && EngineState.wallDrawing.active
        && EngineState.wallDrawing.startWorld && EngineState.wallDrawing.currentWorld) {
      const s = EngineState.wallDrawing.startWorld;
      const c = EngineState.wallDrawing.currentWorld;
      const x0 = Math.min(s.x, c.x);
      const y0 = Math.min(s.y, c.y);
      const ww = Math.abs(c.x - s.x);
      const hh = Math.abs(c.y - s.y);
      ctx.save();
      ctx.fillStyle = "rgba(0, 245, 155, 0.2)";
      ctx.strokeStyle = "#00F59B";
      ctx.lineWidth = 2 / Camera.zoom;
      ctx.setLineDash([6 / Camera.zoom, 4 / Camera.zoom]);
      ctx.fillRect(x0, y0, ww, hh);
      ctx.strokeRect(x0, y0, ww, hh);
      ctx.setLineDash([]);
      ctx.restore();
    }

    ctx.restore();

    render2DLighting(objects);

    if (!EngineState.playMode) {
      ctx.save();
      ctx.translate(canvas.width * .5, canvas.height * .5);
      ctx.scale(Camera.zoom, Camera.zoom);
      ctx.translate(-Camera.x, -Camera.y);
      drawLevelBounds();
      drawGrid();
      ctx.restore();
    }

    if (gizmo) gizmo.draw(ctx);

    if (EngineState.playMode && EngineState.showHudVars && EngineState.variables.length > 0) {
      ctx.save();
      ctx.fillStyle = "rgba(6, 9, 19, 0.82)";
      ctx.strokeStyle = "rgba(255, 255, 255, 0.25)";
      ctx.lineWidth = 1;
      const hudText = EngineState.variables.map((v) => `${v.name}: ${v.value}`).join("  ·  ");
      ctx.font = "600 13px \"JetBrains Mono\", monospace";
      const boxW = Math.min(ctx.measureText(hudText).width + 24, canvas.width - 40);
      ctx.fillRect(14, 14, boxW, 34);
      ctx.strokeRect(14, 14, boxW, 34);
      ctx.fillStyle = "#F1F5F9";
      ctx.textBaseline = "middle";
      ctx.fillText(hudText, 26, 31, boxW - 20);
      ctx.restore();
    }

    const camReadout = document.getElementById("hud-cam-readout");
    if (camReadout && !EngineState.playMode) {
      camReadout.textContent = `Камера: ${Math.round(Camera.x)}, ${Math.round(Camera.y)} · ${Math.round(Camera.zoom * 100)}% · Объектов: ${objects.length}`;
    }

    requestAnimationFrame(mainLoop);
  }

  function consoleLog(msg) {
    const box = document.getElementById("code-console");
    if (!box) return;
    const time = new Date().toLocaleTimeString("ru-RU", { hour12: false });
    box.textContent = `[${time}] ${msg}\n` + box.textContent.slice(0, 1800);
  }

  async function initPyodideSafe() {
    if (pyodideInstance || pyodideLoading) return pyodideInstance;
    pyodideLoading = true;
    try {
      if (typeof window.loadPyodide === "function") {
        consoleLog("Загрузка Python...");
        pyodideInstance = await window.loadPyodide();
        consoleLog("Pyodide готов!");
      } else {
        consoleLog("Pyodide CDN недоступен.");
      }
    } catch (err) {
      consoleLog("Оффлайн Python: " + err.message);
    } finally {
      pyodideLoading = false;
    }
    return pyodideInstance;
  }

  async function runUserCode(silentUpdate = false) {
    if (EngineState.codeLanguage === "game") {
      if (!silentUpdate) consoleLog("game.js выполняется только в экспорте (runtime.js).");
      return;
    }

    const objects = getSceneObjects();
    const varsMap = {};
    for (const v of EngineState.variables) varsMap[v.name] = v.value;

    const engineAPI = {
      objects, camera: Camera, vars: varsMap,
      getObjectByName: (name) => objects.find((o) => o.name === name),
      log: (text) => { if (!silentUpdate) consoleLog(String(text)); },
      net: {
        send: (type, payload) => window.TapNet?.send(type, payload),
        on: (type, fn) => window.TapNet?.on(type, fn),
        players: () => window.TapNet?.players() || []
      }
    };

    if (EngineState.codeLanguage === "javascript") {
      try {
        const fn = new Function("engine", EngineState.jsCode);
        fn(engineAPI);
        for (const v of EngineState.variables) {
          if (varsMap[v.name] !== undefined) v.value = varsMap[v.name];
        }
        if (!silentUpdate) syncAllUI();
      } catch (err) {
        if (!silentUpdate) consoleLog("Ошибка JS: " + err.message);
      }
    } else if (EngineState.codeLanguage === "python") {
      try {
        if (pyodideInstance) {
          pyodideInstance.globals.set("objects_json", JSON.stringify(objects));
          pyodideInstance.globals.set("vars_json", JSON.stringify(varsMap));
          const wrappedPy = `
import json
objects = json.loads(objects_json)
vars = json.loads(vars_json)
_logs = []
def custom_print(*args):
    _logs.append(" ".join(str(a) for a in args))
print = custom_print
${EngineState.pyCode}
json.dumps({"objects": objects, "vars": vars, "logs": _logs})
`;
          const resStr = await pyodideInstance.runPythonAsync(wrappedPy);
          const parsed = JSON.parse(resStr);
          if (Array.isArray(parsed.objects)) parsed.objects.forEach((u, i) => { if (objects[i]) Object.assign(objects[i], u); });
          if (parsed.vars) for (const v of EngineState.variables) if (parsed.vars[v.name] !== undefined) v.value = parsed.vars[v.name];
          if (!silentUpdate && parsed.logs?.length) parsed.logs.forEach((l) => consoleLog("[Python] " + l));
        }
        if (!silentUpdate) syncAllUI();
      } catch (err) {
        if (!silentUpdate) consoleLog("Ошибка Python: " + err.message);
      }
    }
  }

  function importSpineSkeleton() {
    try {
      const previewBox = document.getElementById("spine-preview-box");
      const id = "obj_" + Date.now() + "_" + objectCounter++;
      const objs = getSceneObjects();
      const base = _makeBaseObject(id, "spine");
      base.name = EngineState.spineFiles.jsonName ? EngineState.spineFiles.jsonName.replace(".json", "") : "Скелет";
      base.shape = "rect";
      base.solid = false;
      if (EngineState.spineFiles.pngDataUrl) {
        const img = new Image();
        img.src = EngineState.spineFiles.pngDataUrl;
        base.imageElement = img;
        base.imageSrc = EngineState.spineFiles.pngDataUrl;
        base.width = 128; base.height = 128;
      }
      objs.push(base);
      if (gizmo) gizmo.selectedObject = base;
      if (window.spine && window.spine.SpinePlayer && EngineState.spineFiles.jsonText && EngineState.spineFiles.atlasText && previewBox) {
        previewBox.innerHTML = "";
        new window.spine.SpinePlayer(previewBox, {
          jsonUrl: "data:application/json;base64," + btoa(unescape(encodeURIComponent(EngineState.spineFiles.jsonText))),
          atlasUrl: "data:text/plain;base64," + btoa(unescape(encodeURIComponent(EngineState.spineFiles.atlasText))),
          showControls: false, alpha: true, backgroundColor: "#00000000"
        });
      } else if (previewBox) {
        previewBox.textContent = `Скелет «${base.name}» добавлен!`;
      }
      pushHistory();
      syncAllUI();
    } catch (err) {
      consoleLog("Spine импорт: " + err.message);
    }
  }

  function startPlayMode() {
    if (EngineState.playMode) return;
    if (EngineState.wallMode) {
      EngineState.wallMode = false;
      EngineState.wallDrawing.active = false;
    }
    EngineState.savedBeforePlay = JSON.stringify({
      scenes: EngineState.scenes,
      activeSceneIndex: EngineState.activeSceneIndex,
      variables: EngineState.variables,
      camera: { x: Camera.x, y: Camera.y, zoom: Camera.zoom, targetId: Camera.targetId }
    });
    EngineState.playMode = true;
    document.body.classList.add("play-mode");
    resizeCanvas();
    executeLogicRules("onStart", null);
  }

  function stopPlayMode() {
    if (!EngineState.playMode) return;
    EngineState.playMode = false;
    document.body.classList.remove("play-mode");
    if (EngineState.savedBeforePlay) {
      try {
        const snap = JSON.parse(EngineState.savedBeforePlay);
        EngineState.scenes = snap.scenes;
        EngineState.activeSceneIndex = snap.activeSceneIndex;
        EngineState.variables = snap.variables;
        Camera.x = snap.camera.x; Camera.y = snap.camera.y;
        Camera.zoom = snap.camera.zoom; Camera.targetId = snap.camera.targetId;
        for (const sc of EngineState.scenes) {
          for (const o of sc.objects) {
            if (o.imageSrc && !o.imageElement) {
              const img = new Image();
              img.src = o.imageSrc;
              o.imageElement = img;
            }
          }
        }
      } catch (_) {}
    }
    if (gizmo) gizmo.selectedObject = null;
    resizeCanvas();
    syncAllUI();
  }

  function generateExportPreview() {
    const data = {
      version: "1.0",
      level: { width: LEVEL_WIDTH, height: LEVEL_HEIGHT },
      bgColor: EngineState.bgColor,
      serverUrl: EngineState.serverUrl || null,
      multiplayer: !!EngineState.multiplayerExport,
      playerName: EngineState.playerName,
      playerColor: EngineState.playerColor,
      mpButton: {
        enabled: !!EngineState.mpButtonEnabled,
        text: EngineState.mpButtonText,
        mode: EngineState.mpButtonMode
      },
      scenes: EngineState.scenes.map(s => ({
        id: s.id, name: s.name, bgColor: s.bgColor,
        ambientDarkness: s.ambientDarkness || 0,
        objects: s.objects.length
      })),
      variables: EngineState.variables,
      logicRulesCount: EngineState.logicRules.length,
      audios: (EngineState.audios || []).map(a => a.name),
      playerSprites: Object.keys(EngineState.playerSprites || {}).filter(k => EngineState.playerSprites[k]),
      gameJsLength: (EngineState.gameJsCode || "").length
    };
    return JSON.stringify(data, null, 2);
  }

  function syncAllUI() {
    const scene = getCurrentScene();
    const objects = scene.objects;
    const sel = gizmo ? gizmo.selectedObject : null;

    const darkSlider = document.getElementById("ambient-darkness-slider");
    const darkVal = document.getElementById("ambient-darkness-val");
    if (darkSlider) darkSlider.value = scene.ambientDarkness || 0;
    if (darkVal) darkVal.textContent = Number(scene.ambientDarkness || 0).toFixed(2);

    const bgPicker = document.getElementById("bg-color-picker");
    if (bgPicker) bgPicker.value = EngineState.bgColor;

    const zoomSlider = document.getElementById("camera-zoom-slider");
    const zoomVal = document.getElementById("camera-zoom-val");
    if (zoomSlider) zoomSlider.value = Camera.zoom;
    if (zoomVal) zoomVal.textContent = Math.round(Camera.zoom * 100) + "%";

    const followSelect = document.getElementById("camera-follow-select");
    if (followSelect) {
      followSelect.innerHTML = "<option value=\"\">Свободная камера (Нет)</option>";
      for (const o of objects) {
        const opt = document.createElement("option");
        opt.value = o.id;
        opt.textContent = `${o.name} (${o.type})`;
        if (Camera.targetId === o.id || o.cameraFollow) opt.selected = true;
        followSelect.appendChild(opt);
      }
    }

    const scenesList = document.getElementById("scenes-list");
    if (scenesList) {
      scenesList.innerHTML = "";
      EngineState.scenes.forEach((sc, idx) => {
        const row = document.createElement("div");
        row.className = "list-row" + (idx === EngineState.activeSceneIndex ? " active-row" : "");
        row.innerHTML = `
          <div class="list-row-info">
            <span class="list-row-title">${sc.name}</span>
            <span class="list-row-sub">Объектов: ${sc.objects.length} · Темнота: ${Number(sc.ambientDarkness || 0).toFixed(2)}</span>
          </div>
          <div class="field-row">
            <button type="button" class="action-btn primary" data-switch-scene="${idx}">Открыть</button>
            ${EngineState.scenes.length > 1 ? `<button type="button" class="action-btn danger" data-del-scene="${idx}">✕</button>` : ""}
          </div>
        `;
        scenesList.appendChild(row);
      });
    }

    const emptyHint = document.getElementById("props-empty-hint");
    const propsForm = document.getElementById("props-form");

    if (!sel) {
      if (emptyHint) emptyHint.style.display = "flex";
      if (propsForm) propsForm.style.display = "none";
    } else {
      if (emptyHint) emptyHint.style.display = "none";
      if (propsForm) propsForm.style.display = "flex";
      const setVal = (id, v) => {
        const el = document.getElementById(id);
        if (el && document.activeElement !== el) el.value = v;
      };
      setVal("prop-name", sel.name || "");
      setVal("prop-x", Math.round(sel.x));
      setVal("prop-y", Math.round(sel.y));
      setVal("prop-w", Math.round(sel.width));
      setVal("prop-h", Math.round(sel.height));
      setVal("prop-rot", Math.round(sel.rotation || 0));
      setVal("prop-color", sel.color || COLORS.block);
      setVal("prop-alpha", sel.alpha ?? 1);
      setVal("prop-z", sel.z ?? 0);
      setVal("prop-parallax", sel.parallaxFactor ?? 1);

      const shapeSelect = document.getElementById("prop-shape");
      if (shapeSelect) shapeSelect.value = sel.shape || "rect";

      const chkFollow = document.getElementById("prop-cam-follow");
      if (chkFollow) chkFollow.checked = Boolean(sel.cameraFollow);
      const chkGrav = document.getElementById("prop-gravity");
      if (chkGrav) chkGrav.checked = Boolean(sel.gravity);
      const chkSolid = document.getElementById("prop-solid");
      if (chkSolid) chkSolid.checked = Boolean(sel.solid);
      const chkCtrl = document.getElementById("prop-controllable");
      if (chkCtrl) chkCtrl.checked = Boolean(sel.controllable);
      const chkEmits = document.getElementById("prop-emits-light");
      if (chkEmits) chkEmits.checked = Boolean(sel.emitsLight);

      const lightGroup = document.getElementById("light-props-group");
      if (lightGroup) {
        lightGroup.style.display = sel.emitsLight ? "flex" : "none";
        setVal("prop-light-radius", sel.radius || 180);
        setVal("prop-light-intensity", sel.intensity ?? .9);
        setVal("prop-light-softness", sel.softness ?? .5);
        setVal("prop-light-rgba", sel.rgba || DEFAULT_LIGHT_RGBA);
      }
    }

    const varsList = document.getElementById("vars-list");
    if (varsList) {
      varsList.innerHTML = "";
      EngineState.variables.forEach((v, idx) => {
        const row = document.createElement("div");
        row.className = "list-row";
        row.innerHTML = `
          <div class="list-row-info">
            <span class="list-row-title">${v.name}</span>
            <span class="list-row-sub">Тип: ${v.type} · Значение: ${v.value}</span>
          </div>
          <div class="field-row">
            <button type="button" class="action-btn blue" data-inc-var="${idx}">+1</button>
            <button type="button" class="action-btn danger" data-del-var="${idx}">✕</button>
          </div>
        `;
        varsList.appendChild(row);
      });
    }

    const logicList = document.getElementById("logic-list");
    if (logicList) {
      logicList.innerHTML = "";
      if (EngineState.logicRules.length === 0) {
        logicList.innerHTML = "<div class=\"list-row-sub\">Пока нет правил.</div>";
      } else {
        EngineState.logicRules.forEach((r, idx) => {
          const actionsSummary = (r.then || []).map((a, i) => `${i + 1}. ${a.action}`).join(" → ");
          const condText = r.condition ? ` · ЕСЛИ ${r.condition.varName} ${r.condition.op} ${r.condition.value}` : "";
          const row = document.createElement("div");
          row.className = "list-row";
          row.innerHTML = `
            <div class="list-row-info">
              <span class="list-row-title">КОГДА [${r.when?.event || "?"}]${condText}</span>
              <span class="list-row-sub">${actionsSummary || "нет действий"}</span>
            </div>
            <button type="button" class="action-btn danger" data-del-logic="${idx}">✕</button>
          `;
          logicList.appendChild(row);
        });
      }
    }

    const logicBuilderRoot = document.getElementById("logic-builder-root");
    if (logicBuilderRoot && window.LogicChains) {
      window.LogicChains.renderBuilder(EngineState, logicBuilderRoot, () => { pushHistory(); syncAllUI(); });
    }

    const exportPreview = document.getElementById("export-code-preview");
    if (exportPreview) exportPreview.value = generateExportPreview();

    const levelReadout = document.getElementById("level-size-readout");
    if (levelReadout) levelReadout.textContent = `${LEVEL_WIDTH} × ${LEVEL_HEIGHT}`;

    const srvInput = document.getElementById("export-server-url");
    if (srvInput && document.activeElement !== srvInput) srvInput.value = EngineState.serverUrl || "";

    const srvInputPanel = document.getElementById("server-url-input");
    if (srvInputPanel && document.activeElement !== srvInputPanel) {
      srvInputPanel.value = EngineState.serverUrl || "";
    }
    const nameInput = document.getElementById("player-name-input");
    if (nameInput && document.activeElement !== nameInput) {
      nameInput.value = EngineState.playerName || "";
    }
    const colorInput = document.getElementById("player-color-input");
    if (colorInput && document.activeElement !== colorInput) {
      colorInput.value = EngineState.playerColor || "#00F59B";
    }
    const chkMp = document.getElementById("chk-export-mp");
    if (chkMp) chkMp.checked = !!EngineState.multiplayerExport;

    const chkMpBtn = document.getElementById("chk-mp-button");
    if (chkMpBtn) chkMpBtn.checked = !!EngineState.mpButtonEnabled;
    const mpBtnTextInput = document.getElementById("mp-button-text");
    if (mpBtnTextInput && document.activeElement !== mpBtnTextInput) {
      mpBtnTextInput.value = EngineState.mpButtonText || "Играть онлайн";
    }
    const mpBtnModeSelect = document.getElementById("mp-button-mode");
    if (mpBtnModeSelect) mpBtnModeSelect.value = EngineState.mpButtonMode || "both";

    const audioList = document.getElementById("audio-list");
    if (audioList) {
      audioList.innerHTML = "";
      const audios = EngineState.audios || [];
      if (audios.length === 0) {
        audioList.innerHTML = "<div class=\"list-row-sub\">Пока нет аудио.</div>";
      } else {
        audios.forEach((a, idx) => {
          const row = document.createElement("div");
          row.className = "list-row";
          row.innerHTML = `
            <div class="list-row-info">
              <span class="list-row-title">🎵 ${a.name}</span>
              <span class="list-row-sub">${a.fileName || ""}</span>
            </div>
            <button type="button" class="action-btn danger" data-del-audio="${idx}">✕</button>
          `;
          audioList.appendChild(row);
        });
      }
    }

    const spritePreview = document.getElementById("sprite-preview");
    if (spritePreview) {
      spritePreview.innerHTML = "";
      const keys = ["idle", "walk", "hide"];
      const labels = { idle: "Idle", walk: "Walk", hide: "Hide" };
      keys.forEach((k) => {
        const sp = (EngineState.playerSprites || {})[k];
        const wrap = document.createElement("div");
        wrap.style.cssText = "display:flex;flex-direction:column;align-items:center;gap:4px;";
        if (sp && sp.dataUrl) {
          wrap.innerHTML = `<img src="${sp.dataUrl}" style="width:48px;height:48px;object-fit:contain;border:1px solid var(--neon-green);border-radius:6px;background:#04070F;" /><span class="list-row-sub">${labels[k]}</span>`;
        } else {
          wrap.innerHTML = `<div style="width:48px;height:48px;border:1px dashed var(--border-subtle);border-radius:6px;display:flex;align-items:center;justify-content:center;color:#475569;">—</div><span class="list-row-sub">${labels[k]}</span>`;
        }
        spritePreview.appendChild(wrap);
      });
    }

    // Кнопка стены
    const btnWall = document.getElementById("btn-add-wall");
    if (btnWall) {
      btnWall.classList.toggle("primary", !!EngineState.wallMode);
      btnWall.textContent = EngineState.wallMode ? "🧱 Стена: ВКЛ (тапни холст)" : "🧱 Стена (рисовать)";
    }
  }
  window.syncAllUI = syncAllUI;

  function setCodeLanguage(lang) {
    const codeEditor = document.getElementById("code-editor");
    if (!codeEditor) return;
    if (EngineState.codeLanguage === "javascript") EngineState.jsCode = codeEditor.value;
    else if (EngineState.codeLanguage === "python") EngineState.pyCode = codeEditor.value;
    else if (EngineState.codeLanguage === "game") EngineState.gameJsCode = codeEditor.value;
    EngineState.codeLanguage = lang;
    if (lang === "javascript") codeEditor.value = EngineState.jsCode;
    else if (lang === "python") codeEditor.value = EngineState.pyCode;
    else if (lang === "game") codeEditor.value = EngineState.gameJsCode;

    const bJs = document.getElementById("toggle-lang-js");
    const bPy = document.getElementById("toggle-lang-py");
    const bGame = document.getElementById("toggle-lang-game");
    if (bJs) bJs.classList.toggle("active", lang === "javascript");
    if (bPy) bPy.classList.toggle("active", lang === "python");
    if (bGame) bGame.classList.toggle("active", lang === "game");

    const hint = document.getElementById("code-game-hint");
    if (hint) hint.style.display = lang === "game" ? "block" : "none";
    const updateLabel = document.getElementById("code-update-label");
    if (updateLabel) updateLabel.style.display = lang === "game" ? "none" : "flex";
    const runBtn = document.getElementById("btn-run-code");
    if (runBtn) runBtn.disabled = (lang === "game");
    if (runBtn) runBtn.style.opacity = (lang === "game") ? "0.5" : "1";

    if (lang === "python") initPyodideSafe();
  }

  function initUIEvents() {
    const tabButtons = document.querySelectorAll(".tab-btn");
    const panels = document.querySelectorAll(".drawer-panel");

    tabButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const targetId = btn.getAttribute("data-tab");
        const targetPanel = document.getElementById(targetId);
        const isAlreadyOpen = targetPanel && targetPanel.classList.contains("open");
        panels.forEach((p) => p.classList.remove("open"));
        tabButtons.forEach((b) => b.classList.remove("active"));
        if (!isAlreadyOpen && targetPanel) {
          targetPanel.classList.add("open");
          btn.classList.add("active");
          if (targetId === "panel-code" && EngineState.codeLanguage === "python") initPyodideSafe();
        }
      });
    });

    document.querySelectorAll(".panel-close-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        panels.forEach((p) => p.classList.remove("open"));
        tabButtons.forEach((b) => b.classList.remove("active"));
      });
    });

    const btnGrid = document.getElementById("btn-grid");
    if (btnGrid) {
      btnGrid.addEventListener("click", () => {
        EngineState.snapToGrid = !EngineState.snapToGrid;
        EngineState.showGrid = EngineState.snapToGrid;
        if (gizmo) gizmo.snapToGrid = EngineState.snapToGrid;
        btnGrid.classList.toggle("active", EngineState.snapToGrid);
        btnGrid.textContent = EngineState.snapToGrid ? "Сетка: 32х32" : "Сетка: ВЫКЛ";
      });
    }

    document.getElementById("btn-save")?.addEventListener("click", async () => {
      if (!window.TapStorage) return;
      const btn = document.getElementById("btn-save");
      const orig = btn.textContent;
      btn.textContent = "⏳...";
      await window.TapStorage.saveProject("default", EngineState);
      btn.textContent = "✅ Готово";
      setTimeout(() => { btn.textContent = orig; }, 1200);
    });

    document.getElementById("btn-new")?.addEventListener("click", async () => {
      if (!confirm("Создать новый проект?")) return;
      EngineState.scenes = [{
        id: "scene_1", name: "Сцена 1 (Главная)",
        bgColor: "#060913", ambientDarkness: 0, objects: []
      }];
      EngineState.activeSceneIndex = 0;
      EngineState.variables = [
        { name: "score", type: "number", value: 0 },
        { name: "hp",    type: "number", value: 100 }
      ];
      EngineState.logicRules = [];
      EngineState.bgColor = "#060913";
      EngineState.audios = [];
      EngineState.playerSprites = { idle: null, walk: null, hide: null };
      if (gizmo) gizmo.selectedObject = null;
      pushHistory();
      syncAllUI();
      if (window.TapStorage) await window.TapStorage.saveProject("default", EngineState);
      consoleLog("Новый проект создан.");
    });

    document.getElementById("btn-undo")?.addEventListener("click", undoAction);
    document.getElementById("btn-redo")?.addEventListener("click", redoAction);
    document.getElementById("btn-play")?.addEventListener("click", startPlayMode);
    document.getElementById("btn-stop-play")?.addEventListener("click", stopPlayMode);

    document.getElementById("hud-add-block")?.addEventListener("click", () => createSceneObject("block"));
    document.getElementById("hud-add-light")?.addEventListener("click", () => createSceneObject("light"));

    // === Кнопка «Удалить все стены» (динамически) ===
    const clearBtn = document.getElementById("btn-clear-scene");
    if (clearBtn && clearBtn.parentNode && !document.getElementById("btn-clear-walls")) {
      const wallClear = document.createElement("button");
      wallClear.id = "btn-clear-walls";
      wallClear.className = "action-btn danger";
      wallClear.type = "button";
      wallClear.textContent = "🧱 Удалить стены";
      wallClear.style.cssText = "background:rgba(255,77,109,0.08);border-color:rgba(255,77,109,0.3);color:#FF4D6D;font-size:12px;";
      wallClear.addEventListener("click", () => {
        const objs = getSceneObjects();
        const before = objs.length;
        const filtered = objs.filter(o => o.type !== "wall");
        const removed = before - filtered.length;
        if (removed === 0) { consoleLog("Стен нет"); return; }
        getCurrentScene().objects = filtered;
        if (gizmo) gizmo.selectedObject = null;
        pushHistory();
        syncAllUI();
        consoleLog(`Удалено стен: ${removed}`);
      });
      clearBtn.parentNode.insertBefore(wallClear, clearBtn.nextSibling);
    }

    document.getElementById("btn-add-rect")?.addEventListener("click", () => createSceneObject("block"));
    document.getElementById("btn-add-circle")?.addEventListener("click", () => createSceneObject("circle"));
    document.getElementById("btn-add-triangle")?.addEventListener("click", () => createSceneObject("triangle"));
    document.getElementById("btn-add-line")?.addEventListener("click", () => createSceneObject("line"));
    document.getElementById("btn-add-platform")?.addEventListener("click", () => createSceneObject("platform"));
    document.getElementById("btn-add-coin")?.addEventListener("click", () => createSceneObject("trigger"));
    document.getElementById("btn-add-light")?.addEventListener("click", () => createSceneObject("light"));
    document.getElementById("btn-add-spawn")?.addEventListener("click", () => createSceneObject("spawnPoint"));

    // === Режим стены ===
    document.getElementById("btn-add-wall")?.addEventListener("click", () => {
      EngineState.wallMode = !EngineState.wallMode;
      if (!EngineState.wallMode) {
        EngineState.wallDrawing.active = false;
        EngineState.wallDrawing.startWorld = null;
        EngineState.wallDrawing.currentWorld = null;
      }
      syncAllUI();
      consoleLog(EngineState.wallMode ? "Режим стены: тапни или потяни на холсте" : "Режим стены выключен");
    });

    const _wallCanvas = document.getElementById("game-canvas");

    _wallCanvas.addEventListener("pointerdown", (e) => {
      if (!EngineState.wallMode || EngineState.playMode) return;
      e.preventDefault();
      try { _wallCanvas.setPointerCapture(e.pointerId); } catch (_) {}
      const rect = _wallCanvas.getBoundingClientRect();
      const sx = (e.clientX - rect.left) * (_wallCanvas.width / rect.width);
      const sy = (e.clientY - rect.top) * (_wallCanvas.height / rect.height);
      const wx = (sx - _wallCanvas.width * 0.5) / Camera.zoom + Camera.x;
      const wy = (sy - _wallCanvas.height * 0.5) / Camera.zoom + Camera.y;
      EngineState.wallDrawing.active = true;
      EngineState.wallDrawing.startWorld = { x: wx, y: wy };
      EngineState.wallDrawing.currentWorld = { x: wx, y: wy };
    });

    _wallCanvas.addEventListener("pointermove", (e) => {
      if (!EngineState.wallMode || !EngineState.wallDrawing.active) return;
      const rect = _wallCanvas.getBoundingClientRect();
      const sx = (e.clientX - rect.left) * (_wallCanvas.width / rect.width);
      const sy = (e.clientY - rect.top) * (_wallCanvas.height / rect.height);
      const wx = (sx - _wallCanvas.width * 0.5) / Camera.zoom + Camera.x;
      const wy = (sy - _wallCanvas.height * 0.5) / Camera.zoom + Camera.y;
      EngineState.wallDrawing.currentWorld = { x: wx, y: wy };
    });

    _wallCanvas.addEventListener("pointerup", () => {
      if (!EngineState.wallMode || !EngineState.wallDrawing.active) return;
      _finishWallDrawing();
    });

    _wallCanvas.addEventListener("pointercancel", () => {
      if (EngineState.wallDrawing.active) {
        EngineState.wallDrawing.active = false;
        EngineState.wallDrawing.startWorld = null;
        EngineState.wallDrawing.currentWorld = null;
      }
    });

    document.getElementById("btn-add-sprite")?.addEventListener("click", () => {
      document.getElementById("sprite-upload-input")?.click();
    });
    document.getElementById("sprite-upload-input")?.addEventListener("change", async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      await createSpriteFromFile(file);
      e.target.value = "";
    });

    document.getElementById("ambient-darkness-slider")?.addEventListener("input", (e) => {
      const val = parseFloat(e.target.value) || 0;
      getCurrentScene().ambientDarkness = val;
      const lbl = document.getElementById("ambient-darkness-val");
      if (lbl) lbl.textContent = val.toFixed(2);
    });

    document.getElementById("bg-color-picker")?.addEventListener("input", (e) => {
      EngineState.bgColor = e.target.value;
      getCurrentScene().bgColor = e.target.value;
    });

    document.getElementById("camera-zoom-slider")?.addEventListener("input", (e) => {
      Camera.zoom = parseFloat(e.target.value) || 1;
      syncAllUI();
    });

    document.getElementById("btn-reset-camera")?.addEventListener("click", () => {
      Camera.x = 0; Camera.y = 0; Camera.zoom = 1; Camera.targetId = null;
      syncAllUI();
    });

    document.getElementById("camera-follow-select")?.addEventListener("change", (e) => {
      const id = e.target.value || null;
      Camera.targetId = id;
      getSceneObjects().forEach((o) => { o.cameraFollow = o.id === id; });
      syncAllUI();
    });

    document.getElementById("btn-add-scene")?.addEventListener("click", () => {
      const inp = document.getElementById("new-scene-name");
      const name = inp && inp.value.trim() || `Сцена ${EngineState.scenes.length + 1}`;
      EngineState.scenes.push({
        id: "scene_" + Date.now(),
        name, bgColor: "#060913", ambientDarkness: 0, objects: []
      });
      EngineState.activeSceneIndex = EngineState.scenes.length - 1;
      if (inp) inp.value = "";
      if (gizmo) gizmo.selectedObject = null;
      pushHistory();
      syncAllUI();
    });

    document.getElementById("btn-clear-scene")?.addEventListener("click", () => {
      getCurrentScene().objects = [];
      if (gizmo) gizmo.selectedObject = null;
      pushHistory();
      syncAllUI();
    });

    document.getElementById("scenes-list")?.addEventListener("click", (e) => {
      const sw = e.target.getAttribute("data-switch-scene");
      const del = e.target.getAttribute("data-del-scene");
      if (sw !== null) {
        EngineState.activeSceneIndex = Number(sw);
        const sc = getCurrentScene();
        EngineState.bgColor = sc.bgColor || "#060913";
        if (gizmo) gizmo.selectedObject = null;
        syncAllUI();
      } else if (del !== null && EngineState.scenes.length > 1) {
        EngineState.scenes.splice(Number(del), 1);
        EngineState.activeSceneIndex = Math.max(0, EngineState.activeSceneIndex - 1);
        syncAllUI();
      }
    });

    const bindPropInput = (id, propKey, isNum = false) => {
      document.getElementById(id)?.addEventListener("input", (e) => {
        if (!gizmo || !gizmo.selectedObject) return;
        gizmo.selectedObject[propKey] = isNum ? parseFloat(e.target.value) || 0 : e.target.value;
      });
    };
    bindPropInput("prop-name", "name", false);
    bindPropInput("prop-x", "x", true);
    bindPropInput("prop-y", "y", true);
    bindPropInput("prop-w", "width", true);
    bindPropInput("prop-h", "height", true);
    bindPropInput("prop-rot", "rotation", true);
    bindPropInput("prop-color", "color", false);
    bindPropInput("prop-alpha", "alpha", true);
    bindPropInput("prop-z", "z", true);
    bindPropInput("prop-parallax", "parallaxFactor", true);
    bindPropInput("prop-light-radius", "radius", true);
    bindPropInput("prop-light-intensity", "intensity", true);
    bindPropInput("prop-light-softness", "softness", true);
    bindPropInput("prop-light-rgba", "rgba", false);

    document.getElementById("prop-shape")?.addEventListener("change", (e) => {
      if (!gizmo || !gizmo.selectedObject) return;
      gizmo.selectedObject.shape = e.target.value;
      syncAllUI();
    });

    document.getElementById("prop-emits-light")?.addEventListener("change", (e) => {
      if (!gizmo || !gizmo.selectedObject) return;
      gizmo.selectedObject.emitsLight = e.target.checked;
      syncAllUI();
    });

    document.getElementById("prop-cam-follow")?.addEventListener("change", (e) => {
      if (!gizmo || !gizmo.selectedObject) return;
      const checked = e.target.checked;
      getSceneObjects().forEach((o) => o.cameraFollow = false);
      gizmo.selectedObject.cameraFollow = checked;
      Camera.targetId = checked ? gizmo.selectedObject.id : null;
      syncAllUI();
    });

    document.getElementById("prop-gravity")?.addEventListener("change", (e) => {
      if (gizmo && gizmo.selectedObject) gizmo.selectedObject.gravity = e.target.checked;
    });
    document.getElementById("prop-solid")?.addEventListener("change", (e) => {
      if (gizmo && gizmo.selectedObject) gizmo.selectedObject.solid = e.target.checked;
    });
    document.getElementById("prop-controllable")?.addEventListener("change", (e) => {
      if (gizmo && gizmo.selectedObject) gizmo.selectedObject.controllable = e.target.checked;
    });

    document.getElementById("btn-clone-obj")?.addEventListener("click", () => {
      if (!gizmo || !gizmo.selectedObject) return;
      const copy = JSON.parse(JSON.stringify(gizmo.selectedObject));
      delete copy.imageElement;
      copy.id = "obj_" + Date.now();
      copy.name = copy.name + " (Копия)";
      copy.x += 32; copy.y += 32;
      if (copy.imageSrc) {
        const img = new Image();
        img.src = copy.imageSrc;
        copy.imageElement = img;
      }
      getSceneObjects().push(copy);
      gizmo.selectedObject = copy;
      pushHistory();
      syncAllUI();
    });

    document.getElementById("btn-delete-obj")?.addEventListener("click", () => {
      if (!gizmo || !gizmo.selectedObject) return;
      const objs = getSceneObjects();
      const idx = objs.indexOf(gizmo.selectedObject);
      if (idx !== -1) objs.splice(idx, 1);
      gizmo.selectedObject = null;
      pushHistory();
      syncAllUI();
    });

    document.getElementById("btn-add-var")?.addEventListener("click", () => {
      const nameEl = document.getElementById("var-name");
      const typeEl = document.getElementById("var-type");
      const valEl = document.getElementById("var-value");
      const name = (nameEl?.value || "").trim();
      if (!name) return;
      const type = typeEl?.value || "number";
      let value = valEl?.value || "0";
      if (type === "number") value = parseFloat(value) || 0;
      if (type === "boolean") value = value === "true" || value === "1";
      EngineState.variables.push({ name, type, value });
      if (nameEl) nameEl.value = "";
      if (valEl) valEl.value = "";
      pushHistory();
      syncAllUI();
    });

    document.getElementById("vars-list")?.addEventListener("click", (e) => {
      const inc = e.target.getAttribute("data-inc-var");
      const del = e.target.getAttribute("data-del-var");
      if (inc !== null) {
        const v = EngineState.variables[Number(inc)];
        if (v && v.type === "number") v.value = Number(v.value) + 1;
        syncAllUI();
      } else if (del !== null) {
        EngineState.variables.splice(Number(del), 1);
        syncAllUI();
      }
    });

    document.getElementById("logic-list")?.addEventListener("click", (e) => {
      const del = e.target.getAttribute("data-del-logic");
      if (del !== null) {
        EngineState.logicRules.splice(Number(del), 1);
        pushHistory();
        syncAllUI();
      }
    });

    const codeEditor = document.getElementById("code-editor");
    if (codeEditor) {
      const lang = EngineState.codeLanguage || "javascript";
      if (lang === "game") codeEditor.value = EngineState.gameJsCode;
      else if (lang === "python") codeEditor.value = EngineState.pyCode;
      else codeEditor.value = EngineState.jsCode;

      codeEditor.addEventListener("input", () => {
        if (EngineState.codeLanguage === "javascript") EngineState.jsCode = codeEditor.value;
        else if (EngineState.codeLanguage === "python") EngineState.pyCode = codeEditor.value;
        else if (EngineState.codeLanguage === "game") EngineState.gameJsCode = codeEditor.value;
      });
    }

    document.getElementById("toggle-lang-js")?.addEventListener("click", () => {
      setCodeLanguage("javascript"); consoleLog("Язык: JavaScript");
    });
    document.getElementById("toggle-lang-py")?.addEventListener("click", () => {
      setCodeLanguage("python"); consoleLog("Язык: Python"); initPyodideSafe();
    });
    document.getElementById("toggle-lang-game")?.addEventListener("click", () => {
      setCodeLanguage("game"); consoleLog("Редактор: game.js (выполняется в экспорте)");
    });

    document.getElementById("chk-code-update")?.addEventListener("change", (e) => {
      EngineState.runCodeOnUpdate = e.target.checked;
    });
    document.getElementById("btn-run-code")?.addEventListener("click", () => runUserCode(false));
    document.getElementById("btn-clear-console")?.addEventListener("click", () => {
      const box = document.getElementById("code-console");
      if (box) box.textContent = "";
    });

    document.getElementById("btn-add-audio")?.addEventListener("click", () => {
      const nameEl = document.getElementById("audio-name-input");
      const fileEl = document.getElementById("audio-file-input");
      const name = (nameEl?.value || "").trim();
      const file = fileEl?.files?.[0];
      if (!name) { alert("Введи имя аудио"); return; }
      if (!file) { alert("Выбери файл"); return; }
      const reader = new FileReader();
      reader.onload = () => {
        EngineState.audios.push({ name, fileName: file.name, dataUrl: reader.result });
        if (nameEl) nameEl.value = "";
        if (fileEl) fileEl.value = "";
        syncAllUI();
        if (window.TapStorage) window.TapStorage.saveProject("default", EngineState);
      };
      reader.readAsDataURL(file);
    });

    document.getElementById("audio-list")?.addEventListener("click", (e) => {
      const del = e.target.getAttribute("data-del-audio");
      if (del !== null) {
        EngineState.audios.splice(Number(del), 1);
        syncAllUI();
        if (window.TapStorage) window.TapStorage.saveProject("default", EngineState);
      }
    });

    const _loadPlayerSprite = (inputId, key) => {
      document.getElementById(inputId)?.addEventListener("change", (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          EngineState.playerSprites[key] = { fileName: file.name, dataUrl: reader.result };
          syncAllUI();
          if (window.TapStorage) window.TapStorage.saveProject("default", EngineState);
        };
        reader.readAsDataURL(file);
        e.target.value = "";
      });
    };
    _loadPlayerSprite("sprite-idle-input", "idle");
    _loadPlayerSprite("sprite-walk-input", "walk");
    _loadPlayerSprite("sprite-hide-input", "hide");

    document.getElementById("spine-png-input")?.addEventListener("change", (e) => {
      const file = e.target.files?.[0]; if (!file) return;
      EngineState.spineFiles.pngName = file.name;
      const r = new FileReader();
      r.onload = () => { EngineState.spineFiles.pngDataUrl = r.result; };
      r.readAsDataURL(file);
    });
    document.getElementById("spine-atlas-input")?.addEventListener("change", (e) => {
      const file = e.target.files?.[0]; if (!file) return;
      EngineState.spineFiles.atlasName = file.name;
      const r = new FileReader();
      r.onload = () => { EngineState.spineFiles.atlasText = r.result; };
      r.readAsText(file);
    });
    document.getElementById("spine-json-input")?.addEventListener("change", (e) => {
      const file = e.target.files?.[0]; if (!file) return;
      EngineState.spineFiles.jsonName = file.name;
      const r = new FileReader();
      r.onload = () => { EngineState.spineFiles.jsonText = r.result; };
      r.readAsText(file);
    });
    document.getElementById("btn-import-spine")?.addEventListener("click", importSpineSkeleton);

    const exportModal = document.getElementById("export-modal");
    const exportPreview = document.getElementById("export-code-preview");

    function updateExportView(target) {
      EngineState.exportTarget = target;
      document.querySelectorAll(".export-target-btn").forEach((b) => {
        b.classList.toggle("active", b.getAttribute("data-export-target") === target);
      });
      if (exportPreview) exportPreview.value = generateExportPreview();
    }

    document.getElementById("btn-export")?.addEventListener("click", () => {
      if (exportModal) {
        exportModal.classList.add("open");
        updateExportView(EngineState.exportTarget);
        const srvInput = document.getElementById("export-server-url");
        if (srvInput) srvInput.value = EngineState.serverUrl || "";
      }
    });

    document.getElementById("btn-close-export")?.addEventListener("click", () => {
      exportModal?.classList.remove("open");
    });
    document.querySelectorAll(".export-target-btn").forEach((btn) => {
      btn.addEventListener("click", () => updateExportView(btn.getAttribute("data-export-target")));
    });
    document.getElementById("export-server-url")?.addEventListener("input", (e) => {
      EngineState.serverUrl = e.target.value.trim();
      localStorage.setItem("tapeng1ne_server_url", EngineState.serverUrl);
    });

    const setServerStatus = (text, color) => {
      const el = document.getElementById("server-status");
      if (el) { el.textContent = "Статус: " + text; el.style.color = color || "var(--text-muted)"; }
    };

    document.getElementById("server-url-input")?.addEventListener("input", (e) => {
      EngineState.serverUrl = e.target.value.trim();
      localStorage.setItem("tapeng1ne_server_url", EngineState.serverUrl);
    });
    document.getElementById("btn-save-server")?.addEventListener("click", () => {
      localStorage.setItem("tapeng1ne_server_url", EngineState.serverUrl || "");
      setServerStatus("сохранено", "var(--neon-green)");
    });
    document.getElementById("btn-test-server")?.addEventListener("click", async () => {
      if (!window.TapNet) { setServerStatus("net.js не загружен", "var(--danger)"); return; }
      setServerStatus("подключение...", "var(--neon-blue)");
      try {
        await window.TapNet.connect(EngineState.serverUrl);
        setServerStatus("успешно", "var(--neon-green)");
      } catch (e) { setServerStatus("ошибка: " + e.message, "var(--danger)"); }
    });

    document.getElementById("player-name-input")?.addEventListener("input", (e) => {
      EngineState.playerName = e.target.value.trim() || "Игрок";
      localStorage.setItem("tapeng1ne_player_name", EngineState.playerName);
    });
    document.getElementById("player-color-input")?.addEventListener("input", (e) => {
      EngineState.playerColor = e.target.value;
      localStorage.setItem("tapeng1ne_player_color", EngineState.playerColor);
    });
    document.getElementById("chk-export-mp")?.addEventListener("change", (e) => {
      EngineState.multiplayerExport = e.target.checked;
      localStorage.setItem("tapeng1ne_mp_export", e.target.checked ? "1" : "0");
    });
    document.getElementById("chk-mp-button")?.addEventListener("change", (e) => {
      EngineState.mpButtonEnabled = e.target.checked;
      localStorage.setItem("tapeng1ne_mp_btn_enabled", e.target.checked ? "1" : "0");
    });
    document.getElementById("mp-button-text")?.addEventListener("input", (e) => {
      EngineState.mpButtonText = e.target.value || "Играть онлайн";
      localStorage.setItem("tapeng1ne_mp_btn_text", EngineState.mpButtonText);
    });
    document.getElementById("mp-button-mode")?.addEventListener("change", (e) => {
      EngineState.mpButtonMode = e.target.value;
      localStorage.setItem("tapeng1ne_mp_btn_mode", EngineState.mpButtonMode);
    });

    document.getElementById("btn-copy-export")?.addEventListener("click", () => {
      if (!exportPreview) return;
      navigator.clipboard?.writeText(exportPreview.value);
      const b = document.getElementById("btn-copy-export");
      if (b) { const o = b.textContent; b.textContent = "Скопировано!"; setTimeout(() => b.textContent = o, 1400); }
    });

    document.getElementById("btn-download-export")?.addEventListener("click", async () => {
      if (window.Exporter && typeof window.Exporter.exportGameZip === "function") {
        const mp = EngineState.multiplayerExport || document.getElementById("export-multiplayer")?.checked || false;
        await window.Exporter.exportGameZip(EngineState, { LEVEL_WIDTH, LEVEL_HEIGHT }, { multiplayer: mp });
      } else {
        consoleLog("Модуль exporter.js не подключён!");
      }
    });

    window.addEventListener("keydown", (e) => { activeKeys[e.code] = true; });
    window.addEventListener("keyup", (e) => { activeKeys[e.code] = false; });
  }

  async function initImmersiveMode() {
    try {
      if (window.Capacitor?.Plugins?.StatusBar) {
        await window.Capacitor.Plugins.StatusBar.hide();
        await window.Capacitor.Plugins.StatusBar.setOverlaysWebView({ overlay: true });
      }
      if (document.documentElement.requestFullscreen) {
        const onFirstTap = () => {
          document.documentElement.requestFullscreen?.().catch(() => {});
          document.removeEventListener("pointerdown", onFirstTap);
        };
        document.addEventListener("pointerdown", onFirstTap, { once: true });
      }
    } catch (e) { consoleLog("Immersive: " + e.message); }
  }

  async function bootstrap() {
    resizeCanvas();
    if (window.ShadowRenderer && typeof window.ShadowRenderer.init === "function") window.ShadowRenderer.init();
    if (window.LogicChains) EngineState.logicRules = window.LogicChains.migrateOldRules(EngineState.logicRules);

    if (window.TapStorage) {
      const saved = await window.TapStorage.loadProject("default");
      if (saved) {
        EngineState.scenes = saved.scenes || EngineState.scenes;
        EngineState.activeSceneIndex = saved.activeSceneIndex || 0;
        EngineState.variables = saved.variables || EngineState.variables;
        EngineState.logicRules = saved.logicRules || EngineState.logicRules;
        EngineState.bgColor = saved.bgColor || EngineState.bgColor;
        if (saved.jsCode) EngineState.jsCode = saved.jsCode;
        if (saved.pyCode) EngineState.pyCode = saved.pyCode;
        if (saved.gameJsCode) EngineState.gameJsCode = saved.gameJsCode;
        if (saved.codeLanguage) EngineState.codeLanguage = saved.codeLanguage;
        if (saved.serverUrl) EngineState.serverUrl = saved.serverUrl;
        if (saved.playerName) EngineState.playerName = saved.playerName;
        if (saved.playerColor) EngineState.playerColor = saved.playerColor;
        if (typeof saved.multiplayerExport === "boolean") EngineState.multiplayerExport = saved.multiplayerExport;
        if (typeof saved.mpButtonEnabled === "boolean") EngineState.mpButtonEnabled = saved.mpButtonEnabled;
        if (saved.mpButtonText) EngineState.mpButtonText = saved.mpButtonText;
        if (saved.mpButtonMode) EngineState.mpButtonMode = saved.mpButtonMode;
        if (Array.isArray(saved.audios)) EngineState.audios = saved.audios;
        if (saved.playerSprites) EngineState.playerSprites = Object.assign({ idle: null, walk: null, hide: null }, saved.playerSprites);

        for (const sc of EngineState.scenes) {
          for (const o of sc.objects) {
            if (o.imageSrc && !o.imageElement) {
              const img = new Image();
              img.src = o.imageSrc;
              o.imageElement = img;
            }
          }
        }
        console.log("[Storage] Проект загружен:", new Date(saved.savedAt).toLocaleString("ru-RU"));
      }
    }

    gizmo = new window.TransformGizmo(
      canvas,
      () => Camera,
      () => getSceneObjects(),
      {
        onSelect: () => syncAllUI(),
        onChange: () => syncAllUI(),
        onHistoryCommit: () => {
          pushHistory();
          if (window.TapStorage && !EngineState.playMode) {
            window.TapStorage.saveProject("default", EngineState);
          }
        },
        isPlayMode: () => EngineState.playMode,
        isWallDrawing: () => EngineState.wallMode,
        onPlayTapObject: (tappedObj) => {
          if (tappedObj) executeLogicRules("onTap", tappedObj);
        }
      }
    );

    initUIEvents();
    initImmersiveMode();
    pushHistory();
    syncAllUI();
    setCodeLanguage(EngineState.codeLanguage || "javascript");

    consoleLog("TapEng1ne готов. Модули загружены.");
    requestAnimationFrame(mainLoop);

    if (window.TapStorage) {
      setInterval(() => {
        if (!EngineState.playMode) window.TapStorage.saveProject("default", EngineState);
      }, 30000);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => bootstrap());
  } else {
    bootstrap();
  }
})();