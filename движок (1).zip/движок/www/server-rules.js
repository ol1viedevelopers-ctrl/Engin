// ============================================================
// ПРАВИЛА ИГРЫ: The Hunt (Хоррор-прятки)
// ============================================================

const GAME_DURATION_MS = 3 * 60 * 1000; // 3 минуты
const CATCH_RANGE = 80; // Дистанция поимки

const DEFAULT_SPAWNS = [
  { x: 300, y: 300 }, { x: 700, y: 300 }, { x: 300, y: 700 }, { x: 700, y: 700 },
  { x: 500, y: 500 }, { x: 900, y: 500 }, { x: 500, y: 900 }, { x: 900, y: 900 }
];

module.exports = {
  onJoin(room, player, options, sessionId) {
    player.role = "survivor";
    player.alive = true;
    player.hidden = false;
  },

  onLeave(room, player) {},

  onStart(room) {
    const ids = [...room.state.players.keys()];
    if (ids.length < 2) return false;

    room._gameStart = Date.now();
    room._gameDuration = GAME_DURATION_MS;
    room.state.winner = "";

    // Расставляем всех
    ids.forEach((id, i) => {
      const p = room.state.players.get(id);
      const sp = DEFAULT_SPAWNS[i % DEFAULT_SPAWNS.length];
      p.alive = true;
      p.hidden = false;
      p.customJson = "{}";
      p.x = sp.x + (Math.random() - 0.5) * 50;
      p.y = sp.y + (Math.random() - 0.5) * 50;
      p.role = "survivor";
    });

    // Выбираем одного случайного монстра
    const monsterId = ids[Math.floor(Math.random() * ids.length)];
    const monster = room.state.players.get(monsterId);
    monster.role = "monster";
    monster.customJson = JSON.stringify({ monster: true });
    
    console.log(`[The Hunt] Раунд начался. Монстр: ${monster.name}`);
    return true;
  },

  onMessage(room, client, type, data) {
    const p = room.state.players.get(client.sessionId);
    if (!p || !p.alive) return;

    // Поимка жертвы
    if (type === "catch" && p.role === "monster") {
      const target = room.state.players.get(data.targetId);
      if (!target || !target.alive || target.role === "monster") return;

      // Античит: проверяем дистанцию
      const d = Math.hypot(target.x - p.x, target.y - p.y);
      if (d > CATCH_RANGE) {
        console.warn(`[AntiCheat] Монстр пытался убить слишком далеко: ${Math.round(d)}px`);
        return;
      }

      target.alive = false;
      target.customJson = JSON.stringify({ caught: true });
      room.broadcast("net", { type: "caught", data: { by: p.name, target: target.name }, from: client.sessionId });
    }
  },

  onTick(room) {
    if (room.state.phase !== "playing") return;

    let aliveSurvivors = 0;
    room.state.players.forEach((p) => {
      if (p.alive && p.role !== "monster") aliveSurvivors++;
    });

    // Если всех убили — победа монстра
    if (aliveSurvivors === 0) {
      room.state.phase = "ended";
      room.state.winner = "monster";
      room.broadcast("ended", { winner: "monster" });
      return;
    }

    // Если вышло время — победа выживших
    if (Date.now() - room._gameStart >= room._gameDuration) {
      room.state.phase = "ended";
      room.state.winner = "survivor";
      room.broadcast("ended", { winner: "survivor" });
    }
  }
};