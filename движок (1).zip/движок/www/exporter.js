// EXPORTER.JS — сборка ZIP
(function () {
  "use strict";

  async function exportGameZip(state, levelCfg, options) {
    levelCfg = levelCfg || {};
    options = options || {};

    if (typeof JSZip === "undefined") {
      alert("JSZip не подключён.");
      return;
    }

    const zip = new JSZip();
    const multiplayer = !!options.multiplayer;
    const assets = zip.folder("assets");

    // Аудио
    const audios = state.audios || [];
    const audioEntries = [];
    for (let i = 0; i < audios.length; i++) {
      const a = audios[i];
      if (!a || !a.dataUrl) continue;
      const fn = _safeName(a.fileName || (a.name + ".mp3"));
      assets.file(fn, _dataURLtoBlob(a.dataUrl), { binary: true });
      audioEntries.push({ name: a.name, path: "assets/" + fn });
    }

    // Спрайты персонажа
    const playerSprites = state.playerSprites || {};
    const exportedSprites = {};
    for (const key of ["idle", "walk", "hide"]) {
      const sp = playerSprites[key];
      if (sp && sp.dataUrl) {
        const fn = _safeName(sp.fileName || (key + ".png"));
        assets.file(fn, _dataURLtoBlob(sp.dataUrl), { binary: true });
        exportedSprites[key] = "assets/" + fn;
      } else {
        exportedSprites[key] = null;
      }
    }

    const data = {
      version: "1.0",
      exportedAt: new Date().toISOString(),
      level: {
        width: levelCfg.LEVEL_WIDTH || state.levelWidth || 1920,
        height: levelCfg.LEVEL_HEIGHT || state.levelHeight || 1080
      },
      bgColor: state.bgColor,
      multiplayer: multiplayer,
      serverUrl: multiplayer ? (state.serverUrl || "") : null,
      playerName: state.playerName || "Игрок",
      playerColor: state.playerColor || "#00F59B",
      mpButton: {
        enabled: state.mpButtonEnabled !== false,
        text: state.mpButtonText || "Играть онлайн",
        mode: state.mpButtonMode || "both"
      },
      audios: audioEntries,
      playerSprites: exportedSprites,
      scenes: state.scenes.map(function (s) {
        return {
          id: s.id, name: s.name, bgColor: s.bgColor,
          ambientDarkness: s.ambientDarkness || 0,
          objects: s.objects.map(_serializeObject)
        };
      }),
      variables: state.variables,
      logicRules: state.logicRules,
      settings: { showHudVars: state.showHudVars, startScene: 0 }
    };
    zip.file("data.json", JSON.stringify(data, null, 2));

    // Spine
    if (state.spineFiles) {
      const sf = state.spineFiles;
      if (sf.pngDataUrl) assets.file(_safeName(sf.pngName || "spine.png"), _dataURLtoBlob(sf.pngDataUrl), { binary: true });
      if (sf.atlasText) assets.file(_safeName(sf.atlasName || "spine.atlas"), sf.atlasText);
      if (sf.jsonText) assets.file(_safeName(sf.jsonName || "spine.json"), sf.jsonText);
    }

    // Прочие ассеты
    const stateAssets = state.assets || [];
    for (let i = 0; i < stateAssets.length; i++) {
      const a = stateAssets[i];
      if (!a || !a.dataUrl) continue;
      assets.file(_safeName(a.name || "asset.bin"), _dataURLtoBlob(a.dataUrl), { binary: true });
    }

    // Runtime
    const runtimeSrc = await _fetchText("runtime.js");
    if (runtimeSrc) zip.file("runtime.js", runtimeSrc);

    // game.js
    let gameSrc = state.gameJsCode;
    if (!gameSrc) gameSrc = await _fetchText("game.js");
    if (gameSrc) zip.file("game.js", gameSrc);

    // Net
    if (multiplayer) {
      const netSrc = await _fetchText("net.js");
      if (netSrc) zip.file("net-client.js", netSrc);
    }

    // Icon
    try {
      const iconBlob = await _fetchBlob("icon.png");
      if (iconBlob) zip.file("icon.png", iconBlob);
    } catch (_) {}

    zip.file("index.html", _buildIndexHtml(multiplayer));

    zip.file("README.txt",
      "Игра из TapEng1ne.\n" +
      (multiplayer
        ? "МУЛЬТИПЛЕЕР. Сервер: " + (state.serverUrl || "не указан") + "\n" +
          "Задеплой сервер: файлы server-*.js на Node.js + Colyseus.\n"
        : "ОДИНОЧНАЯ ИГРА.\n") +
      "\nСтруктура:\n  index.html / runtime.js / game.js / data.json / assets/\n" +
      (multiplayer ? "  net-client.js — сетевой клиент\n" : "") +
      "\nАудио: " + audioEntries.length + " файлов\n" +
      "Спрайты персонажа: " + Object.keys(exportedSprites).filter(function (k) { return exportedSprites[k]; }).length + " / 3\n");

    const blob = await zip.generateAsync({
      type: "blob", compression: "DEFLATE",
      compressionOptions: { level: 6 }
    });
    _downloadBlob("my_game.zip", blob);
  }

  function _serializeObject(o) {
    const copy = {};
    for (const k in o) { if (k === "imageElement") continue; copy[k] = o[k]; }
    return copy;
  }
  function _safeName(n) { return String(n).replace(/[^\w.\-]+/g, "_"); }
  function _dataURLtoBlob(dataURL) {
    const parts = dataURL.split(",");
    const meta = parts[0], b64 = parts[1];
    const m = meta.match(/data:([^;]+)/);
    const mime = m ? m[1] : "application/octet-stream";
    const bin = atob(b64);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return new Blob([u8], { type: mime });
  }
  function _downloadBlob(name, blob) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = name;
    document.body.appendChild(a);
    a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 3000);
  }
  async function _fetchText(url) {
    try { const r = await fetch(url); if (r.ok) return await r.text(); } catch (_) {}
    return null;
  }
  async function _fetchBlob(url) {
    try { const r = await fetch(url); if (r.ok) return await r.blob(); } catch (_) {}
    return null;
  }

  function _buildIndexHtml(multiplayer) {
    return '<!DOCTYPE html>\n' +
'<html lang="ru">\n' +
'<head>\n' +
'<meta charset="UTF-8" />\n' +
'<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover" />\n' +
'<title>My Game</title>\n' +
'<link rel="icon" type="image/png" href="./icon.png" />\n' +
'<script src="https://telegram.org/js/telegram-web-app.js"></script>\n' +
'<style>\n' +
'  html,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;background:#060913;touch-action:none;font-family:Outfit,sans-serif}\n' +
'  canvas{display:block;width:100vw;height:100vh}\n' +
'</style>\n' +
'</head>\n' +
'<body>\n' +
'<canvas id="game-canvas"></canvas>\n' +
(multiplayer ? '<script src="https://unpkg.com/colyseus.js@0.15.17/dist/colyseus.js"></script>\n' : '') +
'<script src="runtime.js"></script>\n' +
'<script src="game.js"></script>\n' +
(multiplayer ? '<script src="net-client.js"></script>\n' : '') +
'<script>\n' +
'  window.addEventListener("load", function() {\n' +
'    TapRuntime.start("game-canvas", "data.json"' + (multiplayer ? ', true' : '') + ');\n' +
'  });\n' +
'</script>\n' +
'</body>\n' +
'</html>';
  }

  window.Exporter = { exportGameZip: exportGameZip };
})();